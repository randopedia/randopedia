Ember.TEMPLATES["about-collaboration"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  


  data.buffer.push("<div>\n    <p>\n        To add a new tour or update an existing you have to login. When logged in an \"Add new tour\" button is\n        available in the main menu and an \"Edit\" button appears in the bottom right corner of the tour pages.\n        A new tour can also be created from the area edit page.\n\n        On the tour edit page you can add/update tour details, write a description, upload images and edit the\n        map. Here you can also view the history of all updates that has been made on the tour.\n    </p>\n\n    <h4>Adding links in descriptions</h4>\n    <p>\n        Randopedia supports something called \"markdown\". This means that some codes can be added in a text field and these will be translated\n        into links in view mode. This is supported in the area and tour description fields. Note that the full address must be added (included the http stuff).\n    <p>\n        <strong>Syntax: </strong> [Name](address)\n    </p>\n    <p><strong>Example (in the edit text boxes): </strong></p>\n    <pre><code>Visit us on our [facebook page](http://www.facebook.com/randopedia.net)</code></pre>\n    <p><strong>...will look like this:</strong></p>\n    <pre>Visit us on our <a href=\"http://www.facebook.com/randopedia.net\">facebook page</a></pre>\n\n    <h4>Drafts</h4>\n    <p>\n        Tours can be saved as private drafts. This means the tour is saved, but only visible to you.\n        It's only possible to save drafts for unpublished tours, once published or sent to review the\n        draft option is no longer available.\n    </p>\n    <p>\n        Tour drafts are listed in the \"My tours\" page, available from the main menu.\n    </p>\n    <p>\n        <em>Note:</em> If you have saved tour drafts when logged in with one account, for example Facebook, those tours will not be\n        available if you log in with Google or vice versa.\n    </p>\n\n    <h4>In Review</h4>\n    <p>\n        Tours can be sent to review. This means the tour is still a draft, but it is visible to other logged in users.\n        Tours in review will not appear on the map or in search results. This is useful if you want someone else to review\n        the tour before its published. Maybe you don't have some importanat information that someone else might have or you\n        just want someone else to read through it before it's published. There's a comment section available for tours in review, here\n        you can specify whats missing etc. The review comments will not be visible when the tour has been published.\n    </p>\n    <p>\n        Tours in review are listed in the \"My tours\" page, available from the main menu.\n    </p>\n\n    <h4>Map - Drawing paths</h4>\n    <p>\n        You can select from three different path types. If the path isn't specifically an up or down track, use the default Up/Down type.\n    </p>\n\n    <h4>Map - Summit point</h4>\n    <p>\n        You can set a summit point on the tour. This point is used on the map as the tour marker. If not set, the first point will be used\n        as the tour marker.\n    </p>\n\n    <h4>Map - Importing GPX files</h4>\n    <p>\n        GPX files from gps devices can be uploaded and imported on the map. For preformance reasons the tracks are compressed a bit to reduce the number of points. Only tracks\n        are imported, waypoints and other meta data in the GPX files are ignored. The tracks can be edited on the map after import.\n    </p>\n\n    <h4>Images</h4>\n    <p>\n        In the images section of the tour edit page you can upload images, add/edit image captions and delete images.\n    </p>\n\n    <h4>Areas</h4>\n    <p>\n        Areas also have an edit page. As for tours an \"Edit\" button is available in the bottom right corner of the area pages.\n        On the edit area page you can add subareas and edit the area description.\n    </p>\n    <p>\n        You'll get to an area page by clicking the area name in the breadcrumb on the top of the tour pages.\n    </p>\n</div>");
  
});

Ember.TEMPLATES["about-grades"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  


  data.buffer.push("<div class=\"about-grades-view\">\n    <p>\n        Randopedia uses only one grading system, i.e. there're not separate systems for the climb and the descent. The grade is therefore an overall\n        estimate of all difficulties on an itinerary.\n    </p>\n\n    <p>\n        The grade always evaluates the most difficult part of the itinerary. The main factors that are considered in the estimate are steepness and\n        exposure, but it also includes altitude, duration and how sustained the difficulties are.\n    </p>\n\n    <p>\n        If, for example, an itinerary have a very long duration or is at high altitude the grade might be higher than the grade matching the steepness.\n        This can also be true if there's a very technical passage on an itinerary which isn't very steep.\n    </p>\n\n    <dl>\n        <dt>Easy</dt>\n        <dd>Easy ascent/descent on wide slopes that doesn't require any particular technical abilities.</dd>\n        <dt>Fairly difficult</dt>\n        <dd>Slopes up to 35&#176;. No particulal difficulties but requires solid skiing abilities in all kind of conditions.</dd>\n        <dt>Quite difficult</dt>\n        <dd>Slopes up to 40&#176; (can be down to 30&#176; if technical passages or some exposure). Requires good skiing abilities.</dd>\n        <dt>Difficult</dt>\n        <dd>Slopes up to 45&#176; (can be down to 35&#176; if very technical passages or high exposure, can be up to 50&#176; if low exposure). Requires very good skiing abilities.</dd>\n        <dt>Very difficult</dt>\n        <dd>Slopes up to 50&#176; (can be up to 55&#176; if low exposure).</dd>\n        <dt>Extremely difficult</dt>\n        <dd>Very steep and exposed terrain. Slopes up to 60&#176; and/or long stretches of 50-55&#176;. Serious stuff for the committed and experienced ski mountaineer.</dd>\n    </dl>\n</div>");
  
});

Ember.TEMPLATES["about-help"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  data.buffer.push("<div class=\"panel panel-info\">\n    <div class=\"panel-heading\">Grades</div>\n    <div class=\"panel-body\">\n        ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "about-grades", options) : helperMissing.call(depth0, "partial", "about-grades", options))));
  data.buffer.push("\n    </div>\n</div>\n\n<div class=\"panel panel-default\">\n    <div class=\"panel-heading\">Map</div>\n    <div class=\"panel-body\">\n        <p>\n            There are three different types of paths shown on the map. A tour can have paths of one or many types.\n        </p>\n        <p><span class=\"glyphicon glyphicon-minus default-path\"></span> Default (Can be for both ascent and descent)</p>\n        <p><span class=\"glyphicon glyphicon-minus up-patch\"></span> Suitable for ascent </p>\n        <p><span class=\"glyphicon glyphicon-minus down-path\"></span> Suitable for descent </p>\n    </div>\n</div>\n\n<div class=\"panel panel-info\">\n    <div class=\"panel-heading\">Collaborating</div>\n    <div class=\"panel-body\">\n        ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "about-collaboration", options) : helperMissing.call(depth0, "partial", "about-collaboration", options))));
  data.buffer.push("\n    </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["about"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  data.buffer.push("<div class=\"container-fluid about-view\">\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n\n                <ul class=\"nav nav-tabs\" role=\"tablist\">\n                    <li class=\"active\"><a href=\"#about\" role=\"tab\" data-toggle=\"tab\">About</a></li>\n                    <li><a href=\"#help\" role=\"tab\" data-toggle=\"tab\">Help</a></li>\n                </ul>\n\n                <div class=\"tab-content\">\n\n                    <div class=\"tab-pane active\" id=\"about\">\n                        <div class=\"panel panel-info\">\n                            <div class=\"panel-heading\">Randopedia - The ski tour encyclopedia</div>\n                            <div class=\"panel-body\">\n                                <p>Randopedia is an open-content collaborative encyclopedia where anyone can contribute by adding and update content. Ambition is high; it shall become the most complete and accessible ski tour database in the world. Randopedia doesn't try to be a community or a social network; it's simply a database containing ski tour descriptions.</p>\n                                <p>It's really easy to contribute and take part in the Randopedia vision. Just log in and add your tours! Have a look at the help section if you want to learn more about how to contribute with tour data.</p>\n                            </div>\n                        </div>\n\n                        <div class=\"panel panel-default\">\n                            <div class=\"panel-heading\">The people</div>\n                            <div class=\"panel-body\">\n                                <p>Randopedia is developed and maintained by a bunch of skiers (who also happens to be programmers) who simply thought this was a great idea. All work is done voluntary on our spare time, but we do our best to frequently update and improve the site.</p>\n                                <p>We love to get feedback, so any ideas, suggestions, error reports, questions, criticism or compliments are all very welcomed. Please send an email to <a href=\"mailto:mail@randopedia.net\">mail@randopedia.net</a> or write on the <a target=\"_blank\" href=\"https://www.facebook.com/randopedia.net\">Randopedia Facebook page</a>.</p>\n                            </div>\n                        </div>\n\n                        <div class=\"panel panel-info\">\n                            <div class=\"panel-heading\">Privacy, registering and logging in</div>\n                            <div class=\"panel-body\">\n                                <p>Randopedia doesn't have its own authentication system, instead of creating a new account you can use accounts you already have. Currently you can login with Facebook and Google accounts.</p>\n                                <p>First time you login you have to register the account with Randopedia. This is just a confirmation that you allow your account to be used for authentication by Randopedia.</p>\n                                <p>Randopedia doesn't store or use any sensitive information about your account. The only thing that is saved is the user id and name.</p>\n                                <p><em>Note</em>: You only need to login if you want to contribute with ski tour data or write comments on tours. All ski tours and other information on the site is always available regardless if you're logged in or not.</p>\n                                <p><em>Note</em>: There's a different login for the comments/discussions. If logging in from the discussion panel, you will only be able to add comments, not add/edit tours.</p>\n                            </div>\n                        </div>\n\n                        <div class=\"panel panel-default\">\n                            <div class=\"panel-heading\">Licensing</div>\n                            <div class=\"panel-body\">\n                                <p>\n                                    All tour data (texts, images, map data) is licensed under a <a target=\"_blank\" rel=\"license\" href=\"http://creativecommons.org/licenses/by/4.0/\">Creative Commons Attribution 4.0 International License</a>.\n                                    This basically means that the tour data is, and always will be, free. Anyone can share and redistribute the data freely as long as its done under the same licensing.\n                                    <div>\n                                        <a target=\"_blank\" rel=\"license\" href=\"http://creativecommons.org/licenses/by/4.0/\">\n                                            <img alt=\"Creative Commons License\" class=\"cc-img\" src=\"http://i.creativecommons.org/l/by/4.0/88x31.png\" />\n                                        </a>\n                                    </div>\n                                </p>\n                            </div>\n                        </div>\n\n                        <div class=\"panel panel-danger\">\n                            <div class=\"panel-heading\">Disclaimer</div>\n                            <div class=\"panel-body\">\n                                <p>By publishing any material on Randopedia you assures that the material DO NOT violate ANY copyright law, international or otherwise, nor that the material is deemed illegal by governing authorities.</p>\n                                <p>If you suspect that some material available on Randopedia violates any copyright law, please contact us and it will be immediately deleted from the Randopedia database.</p>\n                                <p>Randopedia makes no guarantee of the validity of the content. Tour data should always be seen as guidelines and inspiration, not as absolute truth, and be handled as such.</p>\n                                <p>Randopedia reserves the right to, without any notice, delete any content that violates anything stated here or is considered irrelevant for the site.</p>\n                            </div>\n                        </div>\n                    </div>\n\n                    <div class=\"tab-pane\" id=\"help\">\n                        ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "about-help", options) : helperMissing.call(depth0, "partial", "about-help", options))));
  data.buffer.push("\n                    </div>\n\n                </div>\n\n            </div>\n        </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["application"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  data.buffer.push("<!--\n    Default application template. Defines the application layout and starts everything off.\n-->     \n\n");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "header", options) : helperMissing.call(depth0, "partial", "header", options))));
  data.buffer.push("\n\n");
  stack1 = helpers._triageMustache.call(depth0, "outlet", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  return buffer;
  
});

Ember.TEMPLATES["components/area-breadcrumb"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n    ");
  stack1 = helpers.unless.call(depth0, "area.parent.isRootArea", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(2, program2, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n");
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n        ");
  data.buffer.push(escapeExpression((helper = helpers['area-breadcrumb'] || (depth0 && depth0['area-breadcrumb']),options={hash:{
    'area': ("area.parent")
  },hashTypes:{'area': "ID"},hashContexts:{'area': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "area-breadcrumb", options))));
  data.buffer.push("\n    ");
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push(" ");
  stack1 = helpers._triageMustache.call(depth0, "area.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" ");
  return buffer;
  }

  stack1 = helpers['if'].call(depth0, "area.parent", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n<li class=\"uppercase\">");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "area", "area", options) : helperMissing.call(depth0, "link-to", "area", "area", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</li>");
  return buffer;
  
});

Ember.TEMPLATES["area-browse-item-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n\n    ");
  stack1 = helpers['if'].call(depth0, "hasTours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(2, program2, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n");
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n		");
  stack1 = helpers['if'].call(depth0, "isExpanded", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(8, program8, data),fn:self.program(3, program3, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n    \n        <a class=\"areatree-link\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "routeToArea", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">");
  stack1 = helpers._triageMustache.call(depth0, "view.areaTitle", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</a>\n\n    ");
  return buffer;
  }
function program3(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n		    ");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(6, program6, data),fn:self.program(4, program4, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n		");
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n		        <a href=\"#\" class=\"areatree-expand\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("><<span class=\"glyphicon glyphicon-minus\"></a>\n	        ");
  return buffer;
  }

function program6(depth0,data) {
  
  
  data.buffer.push("\n	            <span class=\"intent\" class=\"intent\"></span>		        \n		    ");
  }

function program8(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n		    ");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(11, program11, data),fn:self.program(9, program9, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n        ");
  return buffer;
  }
function program9(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n		        <a href=\"#\" class=\"areatree-expand\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-plus\"></i></a>\n            ");
  return buffer;
  }

function program11(depth0,data) {
  
  
  data.buffer.push("\n                <span class=\"intent\"></span>\n		    ");
  }

function program13(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n\n    ");
  stack1 = helpers['if'].call(depth0, "isExpanded", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(19, program19, data),fn:self.program(14, program14, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n    \n    <a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "routeToArea", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">");
  stack1 = helpers._triageMustache.call(depth0, "view.areaTitle", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</a>\n\n");
  return buffer;
  }
function program14(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n        ");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(17, program17, data),fn:self.program(15, program15, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n    ");
  return buffer;
  }
function program15(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n            <a href=\"#\" class=\"areatree-expand\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-minus\"></a>\n        ");
  return buffer;
  }

function program17(depth0,data) {
  
  
  data.buffer.push("\n            <span class=\"intent\"></span>\n        ");
  }

function program19(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n        ");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(17, program17, data),fn:self.program(20, program20, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n    ");
  return buffer;
  }
function program20(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n            <a href=\"#\" class=\"areatree-expand\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-plus\"></a>\n        ");
  return buffer;
  }

function program22(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n    ");
  stack1 = helpers['if'].call(depth0, "isExpanded", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(23, program23, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n");
  return buffer;
  }
function program23(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n        <div class=\"intent-child\">");
  data.buffer.push(escapeExpression((helper = helpers.control || (depth0 && depth0.control),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "areaBrowseItems", "content", options) : helperMissing.call(depth0, "control", "areaBrowseItems", "content", options))));
  data.buffer.push("</div>\n    ");
  return buffer;
  }

  data.buffer.push("\n");
  stack1 = helpers['if'].call(depth0, "controllers.areaBrowse.onlyShowWithTours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(13, program13, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(22, program22, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n");
  return buffer;
  
});

Ember.TEMPLATES["area-browse-items-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n    ");
  data.buffer.push(escapeExpression(helpers.each.call(depth0, "children", {hash:{
    'itemController': ("areaBrowseItem"),
    'itemViewClass': ("App.AreaBrowseItemView")
  },hashTypes:{'itemController': "STRING",'itemViewClass': "STRING"},hashContexts:{'itemController': depth0,'itemViewClass': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n");
  return buffer;
  }

  data.buffer.push("<div class=\"browse-tree-view\">\n");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["area-browse"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  data.buffer.push("\n                        <div class=\"loading\">Loading areas...</div>\n                    ");
  }

function program3(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                        ");
  stack1 = helpers.each.call(depth0, "toplevel", "in", "controller", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                            ");
  stack1 = helpers['if'].call(depth0, "toplevel.area.children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(5, program5, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                        ");
  return buffer;
  }
function program5(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n                                ");
  data.buffer.push(escapeExpression((helper = helpers.control || (depth0 && depth0.control),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "areaBrowseItems", "toplevel.area", options) : helperMissing.call(depth0, "control", "areaBrowseItems", "toplevel.area", options))));
  data.buffer.push("\n                            ");
  return buffer;
  }

  data.buffer.push("<div class=\"container-fluid\">\n\n    <div class=\"row\">    \n        <div class=\"col-sm-12 browse-tree-view\">\n\n            <div class=\"panel panel-default\">\n                <div class=\"panel-heading\">\n                    Browse areas\n                </div>\n                <div class=\"panel-body\">\n                    ");
  stack1 = helpers['if'].call(depth0, "controller.isLoadingAreas", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                </div>\n            </div>\n\n        </div> \n    </div>\n</div>\n\n");
  return buffer;
  
});

Ember.TEMPLATES["area"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var escapeExpression=this.escapeExpression;


  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.AreaDetailsView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  
});

Ember.TEMPLATES["areadetails-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, self=this, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  var stack1, helper, options;
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(2, program2, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "area", "parent", options) : helperMissing.call(depth0, "link-to", "area", "parent", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  else { data.buffer.push(''); }
  }
function program2(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("<span class=\"small uppercase\">");
  stack1 = helpers._triageMustache.call(depth0, "parent.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</span>");
  return buffer;
  }

function program4(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n	<div class=\"row\">\n		<div class=\"col-sm-12\">\n		    <h3>Areas</h3>\n		    <ul class=\"inline-list\">\n		     ");
  stack1 = helpers.each.call(depth0, "child", "in", "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(5, program5, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n		     </ul>\n		</div>\n	</div>\n	");
  return buffer;
  }
function program5(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n		         <li>\n			         ");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(6, program6, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "area", "child", options) : helperMissing.call(depth0, "link-to", "area", "child", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" \n			         \n		         </li>\n		     ");
  return buffer;
  }
function program6(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push(" ");
  stack1 = helpers._triageMustache.call(depth0, "child.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" ");
  return buffer;
  }

function program8(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n		");
  stack1 = helpers['if'].call(depth0, "hasTours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(9, program9, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	");
  return buffer;
  }
function program9(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n			<div class=\"row\">\n			    <div class=\"col-sm-12\">\n			        <h3>Tours</h3>\n			        ");
  stack1 = helpers['if'].call(depth0, "content.isUpdating", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(10, program10, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n			        ");
  stack1 = helpers.each.call(depth0, "tour", "in", "tours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(12, program12, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("  \n			    </div>\n			</div>\n		");
  return buffer;
  }
function program10(depth0,data) {
  
  
  data.buffer.push("\n			            <div>Loading...</div>\n			        ");
  }

function program12(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n			            ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourItemView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n			        ");
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("  \n	");
  stack1 = helpers.unless.call(depth0, "isRootArea", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(15, program15, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	");
  return buffer;
  }
function program15(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n	<div class=\"row\">\n	    <div class=\"col-sm-12 edit-container area\">\n	        ");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(16, program16, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "area.edit", "model", options) : helperMissing.call(depth0, "link-to", "area.edit", "model", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	    </div>       \n	</div>\n	");
  return buffer;
  }
function program16(depth0,data) {
  
  
  data.buffer.push("<span class=\"glyphicon glyphicon-edit\"></span> Edit area");
  }

  data.buffer.push("<div class=\"container-fluid\">\n	<div class=\"row\">\n	    <div class=\"col-sm-12\">\n	        <h2>");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" ");
  stack1 = helpers['if'].call(depth0, "parent", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</h2>\n	    </div>\n	</div>\n	\n	<div class=\"row\">\n	    <div class=\"col-sm-12\">\n	        <div>");
  data.buffer.push(escapeExpression(helpers._triageMustache.call(depth0, "markedDescription", {hash:{
    'unescaped': ("true")
  },hashTypes:{'unescaped': "STRING"},hashContexts:{'unescaped': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("</div>\n	    </div>\n	</div>\n	\n	");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	\n	");
  stack1 = helpers.unless.call(depth0, "isReadOnlyArea", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(8, program8, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	\n	");
  stack1 = helpers['if'].call(depth0, "controllers.login.isLoggedIn", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(14, program14, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	\n</div>\n\n");
  return buffer;
  
});

Ember.TEMPLATES["areaedit-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  data.buffer.push("\n	<div class=\"row\">\n	    <div class=\"col-sm-12\">\n	        <div class=\"alert alert-success\" role=\"alert\">\n	            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n	            Area was successfully updated.\n	        </div>          \n	    </div>\n	</div>\n	");
  }

function program3(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n	            <h2>");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</h2>\n	        ");
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n	        <div class=\"panel panel-default spacing-top\">\n	            <div class=\"panel-heading\">\n	                Area details\n	            </div>\n	            <div class=\"panel-body\">\n			        <form role=\"form\">              \n			            <div class=\"form-group\">\n		                    <label for=\"inputAreaName\">Name</label>\n		                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\" title=\"Name\" data-content=\"The name of the area. Name is required and can have a maximum of 80 characters.\"></button>\n		                    ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'value': ("name"),
    'required': ("true"),
    'maxlength': ("80"),
    'pattern': ("^.{3,80}$"),
    'class': ("form-control"),
    'id': ("inputAreaName")
  },hashTypes:{'value': "ID",'required': "STRING",'maxlength': "STRING",'pattern': "STRING",'class': "STRING",'id': "STRING"},hashContexts:{'value': depth0,'required': depth0,'maxlength': depth0,'pattern': depth0,'class': depth0,'id': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("            \n			            </div>\n			            <div class=\"form-group\">\n		                    <label for=\"inputAreaDescription\">Description</label>\n		                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\" title=\"Description\" data-content=\"A short description of the area. A description can have a maximum of 500 characters.\"></button>\n		                    ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'value': ("description"),
    'maxlength': ("500"),
    'class': ("form-control"),
    'id': ("inputAreaDescription")
  },hashTypes:{'value': "ID",'maxlength': "STRING",'class': "STRING",'id': "STRING"},hashContexts:{'value': depth0,'maxlength': depth0,'class': depth0,'id': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n			            </div>\n			        </form>\n	            </div>\n	        </div>\n	        ");
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n		                  <li>");
  stack1 = helpers._triageMustache.call(depth0, "child.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</li> \n		              ");
  return buffer;
  }

function program9(depth0,data) {
  
  
  data.buffer.push("\n		                  <li>Area has no subareas</li>\n		              ");
  }

function program11(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n	    <div class=\"col-sm-12\">\n	        <div class=\"panel panel-default\">\n	            <div class=\"panel-heading\">\n	                Tours\n	            </div>\n	            <div class=\"panel-body\">\n	                <div class=\"row\">\n	                    <div class=\"col-sm-12\">\n	                        ");
  stack1 = helpers['if'].call(depth0, "tours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(14, program14, data),fn:self.program(12, program12, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	                    </div>\n	                </div>\n	                <div class=\"row\">\n	                    <div class=\"col-sm-12\">\n	                        <button class=\"btn btn-primary pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "addTour", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-plus\"></span> Add new tour</button>\n	                    </div>\n	                </div>\n	            </div>\n	        </div>\n	    </div>\n	    ");
  return buffer;
  }
function program12(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n	                            ");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" currently have ");
  stack1 = helpers._triageMustache.call(depth0, "tours.length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" tours.\n	                        ");
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n	                            There are currently no tours in ");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(".\n	                        ");
  return buffer;
  }

function program16(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                <span class=\"info label alert\">");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" is a root area and cannot be edited, but it's possible to add subareas.</span>\n                ");
  return buffer;
  }

function program18(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n\n                <div class=\"btn-group pull-right\">\n                    <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "startCancelingEdit", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                        <span class=\"glyphicon glyphicon-share\"></span> Exit edit\n                    </button>\n                </div>\n\n                <div class=\"btn-group pull-right\">\n                    <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("isNotDirty")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "saveArea", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                        <span class=\"glyphicon glyphicon-cloud-upload\"></span> Publish\n                    </button>\n                </div>\n\n                <div class=\"saving-info-container pull-right\">\n                    ");
  stack1 = helpers['if'].call(depth0, "isDirty", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(19, program19, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                </div>\n                ");
  return buffer;
  }
function program19(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                    ");
  stack1 = helpers['if'].call(depth0, "havePendingOperations", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(22, program22, data),fn:self.program(20, program20, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program20(depth0,data) {
  
  
  data.buffer.push("\n                    <span class=\"spacing-x-large\"><span class=\"glyphicon glyphicon-floppy-disk\"></span><em> Saving...</em></span>\n                    ");
  }

function program22(depth0,data) {
  
  
  data.buffer.push("\n                    <span class=\"spacing-x-large\"><span class=\"glyphicon glyphicon-floppy-disk\"></span><em class=\"hidden-xs\"> Area has unsaved changes</em></span>\n                    ");
  }

  data.buffer.push("<!-- \n    Template for editing an area\n --> \n<div class=\"container-fluid\">\n\n	");
  stack1 = helpers['if'].call(depth0, "updateSuccessfully", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n		\n	<div class=\"row\">\n	    \n	    <div class=\"col-sm-12\">\n	        ");
  stack1 = helpers['if'].call(depth0, "isReadOnlyArea", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(5, program5, data),fn:self.program(3, program3, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	    </div>\n		    \n	    <div class=\"col-sm-12\">\n		    <div class=\"panel panel-default\">\n		        <div class=\"panel-heading\">\n		            Subareas\n		        </div>\n			    <div class=\"panel-body\">\n		            <ul class=\"inline-list\">\n		              ");
  stack1 = helpers.each.call(depth0, "child", "in", "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n		            </ul>\n		            <div class=\"row\">\n	                    <div class=\"col-sm-12\">  \n		                   <button class=\"btn btn-primary pull-right\" data-toggle=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "startAddSubArea", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(" data-target=\"#addSubAreaModal\"><span class=\"glyphicon glyphicon-plus\"></span> Add new subarea</button>\n		               </div>\n		           </div>\n			    </div>\n		    </div>\n	    </div>\n		    \n	    ");
  stack1 = helpers.unless.call(depth0, "isReadOnlyArea", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(11, program11, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	        \n	</div>\n		\n    <div class=\"modal fade\" id=\"discardChangesAreaModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-body\">\n                    The area has unsaved changes, do you want to discard them?\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-danger pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "cancelEdit", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Discard changes</button>\n                </div>\n            </div>\n        </div>\n    </div> \n		\n    <div class=\"modal fade\" id=\"validationErrorsAreaModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Validation failed</h4>\n                </div>\n                <div class=\"modal-body\">\n                    There are validation errors that must be corrected before the area can be published.\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-primary pull-right\" data-dismiss=\"modal\">OK</button>\n                </div>\n            </div>\n        </div>\n    </div>  \n		\n    <div class=\"modal fade\" id=\"confirmPublishAreaModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Publish area</h4>\n                </div>\n                <div class=\"modal-body\">\n                    <div class=\"alert alert-success\" role=\"alert\">\n                        Area is ready to be be published.\n                    </div>\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-primary pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "saveArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-cloud-upload\"></span> Publish</button>\n                </div>\n            </div>\n        </div>\n    </div> \n		\n    <div class=\"modal fade\" id=\"addSubAreaModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    Add new subarea\n                </div>\n                <div class=\"modal-body\">\n                    <form class=\"form\">\n                        <div class=\"form-group\">\n                            <label>Name</label>\n                            ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.FocusTextField", {hash:{
    'valueBinding': ("newArea.name"),
    'required': ("true"),
    'maxlength': ("80"),
    'pattern': ("^.{3,80}$"),
    'class': ("form-control")
  },hashTypes:{'valueBinding': "STRING",'required': "STRING",'maxlength': "STRING",'pattern': "STRING",'class': "STRING"},hashContexts:{'valueBinding': depth0,'required': depth0,'maxlength': depth0,'pattern': depth0,'class': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                        </div>\n                        <div class=\"form-group\">\n                            <label>Description</label>\n                            ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'value': ("newArea.description"),
    'maxlength': ("500"),
    'class': ("form-control")
  },hashTypes:{'value': "ID",'maxlength': "STRING",'class': "STRING"},hashContexts:{'value': depth0,'maxlength': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n                        </div>\n                    </form>\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "cancelAddSubAreaDialog", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Cancel</button>\n                    <button class=\"btn btn-primary pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "addSubArea", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Add area</button>\n                </div>\n            </div>\n        </div>\n    </div> \n</div>\n\n<nav class=\"edit-navbar\" role=\"toolbar\">\n    <div class=\"container-fluid\">\n\n        <div class=\"navbar-header\">\n            <div class=\"btn-toolbar\">\n                ");
  stack1 = helpers['if'].call(depth0, "isReadOnlyArea", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(18, program18, data),fn:self.program(16, program16, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n            </div>\n        </div>\n\n    </div>\n</nav>");
  return buffer;
  
});

Ember.TEMPLATES["areaedit"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', escapeExpression=this.escapeExpression;


  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.AreaEditView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n");
  return buffer;
  
});

Ember.TEMPLATES["areapicker-item-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n    ");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(4, program4, data),fn:self.program(2, program2, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n");
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n        <a href=\"#\" class=\"areatree-expand\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleExpandChildren", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-minus\"></span></a>\n    ");
  return buffer;
  }

function program4(depth0,data) {
  
  
  data.buffer.push("\n        <span class=\"intent\"></span>\n    ");
  }

function program6(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n    ");
  stack1 = helpers['if'].call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(4, program4, data),fn:self.program(7, program7, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n");
  return buffer;
  }
function program7(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n        <a href=\"#\" class=\"areatree-expand\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleExpandChildren", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-plus\"></span></a>\n    ");
  return buffer;
  }

function program9(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n    <button class=\"areatree is-selected\">");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</button>  \n");
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n    ");
  stack1 = helpers['if'].call(depth0, "isReadOnlyArea", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(14, program14, data),fn:self.program(12, program12, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n");
  return buffer;
  }
function program12(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n        <button class=\"areatree\" disabled=\"disabled\" >");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</button>\n    ");
  return buffer;
  }

function program14(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("    \n        <button class=\"areatree\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "selectArea", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</button>\n    ");
  return buffer;
  }

function program16(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n\n	");
  stack1 = helpers.each.call(depth0, "children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(17, program17, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n");
  return buffer;
  }
function program17(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n	\n	    <div class=\"intent-child\">");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.AreaPickerItemView", {hash:{
    'itemBinding': ("this")
  },hashTypes:{'itemBinding': "STRING"},hashContexts:{'itemBinding': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("</div>\n	\n	");
  return buffer;
  }

  data.buffer.push("\n");
  stack1 = helpers['if'].call(depth0, "view.isExpanded", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(6, program6, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n");
  stack1 = helpers['if'].call(depth0, "view.isSelected", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(11, program11, data),fn:self.program(9, program9, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n");
  stack1 = helpers['if'].call(depth0, "view.isExpanded", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(16, program16, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n");
  return buffer;
  
});

Ember.TEMPLATES["areapicker-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n	\n	    <div class=\"row\">\n	        <div class=\"col-sm-12\">\n	            <h4>Add new area in ");
  stack1 = helpers._triageMustache.call(depth0, "controller.tempSelectedArea.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</h4>\n	        </div>\n	    </div>\n	\n	    <div class=\"row\">\n	        <div class=\"col-sm-12\">\n	            <form role=\"form\">\n	                <div class=\"form-group\">\n	                    <label for=\"inputAreaName\">Name</label>\n	                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.FocusTextField", {hash:{
    'id': ("inputAreaName"),
    'class': ("form-control"),
    'valueBinding': ("newArea.name"),
    'required': ("true"),
    'maxlength': ("80"),
    'pattern': ("^.{3,80}$")
  },hashTypes:{'id': "STRING",'class': "STRING",'valueBinding': "STRING",'required': "STRING",'maxlength': "STRING",'pattern': "STRING"},hashContexts:{'id': depth0,'class': depth0,'valueBinding': depth0,'required': depth0,'maxlength': depth0,'pattern': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n	                </div>\n	                <div class=\"form-group\">\n	                    <label for=\"inputAreaDesc\">Description</label>\n	                    ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'id': ("inputAreaDesc"),
    'value': ("newArea.description"),
    'maxlength': ("300"),
    'class': ("form-control")
  },hashTypes:{'id': "STRING",'value': "ID",'maxlength': "STRING",'class': "STRING"},hashContexts:{'id': depth0,'value': depth0,'maxlength': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n	                </div>\n	                <div class=\"form-group\">\n	                    <hr />\n	                </div>   \n	                <div class=\"form-group\">\n			            <button class=\"btn btn-default pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "cancelAddSubArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Cancel</button>\n			            <button class=\"btn btn-primary pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "addSubArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Add area</button>                  \n	                </div>             \n	            </form>\n	        </div>\n	    </div> \n	    \n	");
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n	\n		");
  stack1 = helpers['if'].call(depth0, "view.loading", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	\n	    ");
  stack1 = helpers.each.call(depth0, "toplevel", "in", "toplevels", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(6, program6, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	 \n		<div class=\"row\">\n		   <div class=\"col-sm-12\">\n		       <hr />\n			    Selected: <strong>");
  stack1 = helpers._triageMustache.call(depth0, "controller.tempSelectedArea.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</strong>\n			    <a class=\"pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "startAddingSubArea", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Add new area in ");
  stack1 = helpers._triageMustache.call(depth0, "controller.tempSelectedArea.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</a>\n		    </div>\n		</div>\n	\n		<div class=\"row\">\n		    <div class=\"col-sm-12\">\n		       <hr />\n		       <button class=\"btn btn-default pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "closeAreaPickerDialog", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Cancel</button>\n		       <button class=\"btn btn-primary pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "confirmSelectedArea", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Set area</button>\n		    </div>\n		</div>\n		\n	");
  return buffer;
  }
function program4(depth0,data) {
  
  
  data.buffer.push("<div class=\"loading\">Loading areas...</div>");
  }

function program6(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n	\n	        ");
  stack1 = helpers['if'].call(depth0, "toplevel.area.children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(7, program7, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	\n	    ");
  return buffer;
  }
function program7(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push(" \n	            \n	            ");
  stack1 = helpers.each.call(depth0, "toplevel.area.children", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(8, program8, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	            \n	        ");
  return buffer;
  }
function program8(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n	            \n	                ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.AreaPickerItemView", {hash:{
    'itemBinding': ("this")
  },hashTypes:{'itemBinding': "STRING"},hashContexts:{'itemBinding': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n	            \n	            ");
  return buffer;
  }

  data.buffer.push("\n<div class=\"browse-tree-view\">  \n	");
  stack1 = helpers['if'].call(depth0, "addSubareaMode", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["components/browse-tourmap"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  data.buffer.push("\n    <div class=\"loading-data\">\n        Waiting for position...\n    </div>\n    ");
  }

function program3(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n    <div class=\"tour-info\">\n        <h4>\n            <button type=\"button\" class=\"close\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "closeInfoWindowAction", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n            ");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "tour", "selectedTour", options) : helperMissing.call(depth0, "link-to", "tour", "selectedTour", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n        </h4>\n        <div>\n            ");
  data.buffer.push(escapeExpression((helper = helpers.resolveGradeName || (depth0 && depth0.resolveGradeName),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "selectedTour.grade", options) : helperMissing.call(depth0, "resolveGradeName", "selectedTour.grade", options))));
  data.buffer.push(" |\n            ");
  stack1 = helpers._triageMustache.call(depth0, "selectedTour.timingMin", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("-");
  stack1 = helpers._triageMustache.call(depth0, "selectedTour.timingMax", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("h |\n            ");
  stack1 = helpers._triageMustache.call(depth0, "selectedTour.elevationGain", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("m &uarr; ");
  stack1 = helpers._triageMustache.call(depth0, "selectedTour.elevationLoss", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("m &darr;\n        </div>\n        <div class=\"link-container\">\n            <span><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "zoomToSelectedTour", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">View on map</a></span>\n            <span class=\"pull-right\">");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(6, program6, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "tour", "selectedTour", options) : helperMissing.call(depth0, "link-to", "tour", "selectedTour", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</span>\n        </div>\n    </div>\n    ");
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push(" ");
  stack1 = helpers._triageMustache.call(depth0, "selectedTour.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" ");
  return buffer;
  }

function program6(depth0,data) {
  
  
  data.buffer.push(" View tour details ");
  }

  data.buffer.push("<div class=\"browse-map-view full-screen\">\n    <div id=\"tourMapRootElement\" class=\"full-screen\"></div>\n    ");
  stack1 = helpers['if'].call(depth0, "waitingForPosition", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n    <button class=\"btn btn-primary btn-my-position\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleMyPosition", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n        <span class=\"glyphicon glyphicon-screenshot\"></span>\n    </button>\n    ");
  stack1 = helpers['if'].call(depth0, "showTourInfo", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(3, program3, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["components/disqus-component"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  


  data.buffer.push("<div class=\"row\" id=\"comments\">\n<div id=\"disqus_thread\" class=\"col-md-8\">\n</div>\n</div>");
  
});

Ember.TEMPLATES["fileupload-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', escapeExpression=this.escapeExpression;


  data.buffer.push("<!--  \n    View that wraps the javascript file uploader. The original UI is hidden\n -->\n \n<input type=\"file\" id=\"fileInputElement\" accept=\"image/*\" class=\" hide\" />\n<button class=\"btn btn-primary\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "openFileDialog", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("havePendingOperations")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(">\n    <span class=\"glyphicon glyphicon-picture\"></span> Select image\n</button>\n");
  return buffer;
  
});

Ember.TEMPLATES["footer"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  


  data.buffer.push("\n<footer>\n    <div class=\"footer-view\">\n\n        <div class=\"row\">\n\n            <div class=\"col-sm-12\">\n                <div>\n                    <!--<a target=\"_blank\" rel=\"license\" href=\"http://creativecommons.org/licenses/by/4.0/\">\n                        <img alt=\"Creative Commons License\" class=\"cc-img\" src=\"http://i.creativecommons.org/l/by/4.0/88x31.png\" />\n                    </a>-->\n                    <div>\n                        All tour data on <span xmlns:dct=\"http://purl.org/dc/terms/\" property=\"dct:title\">randopedia.net</span> is licensed under a <a target=\"_blank\" rel=\"license\" href=\"http://creativecommons.org/licenses/by/4.0/\">Creative Commons Attribution 4.0 International License</a>.\n                    </div>\n                </div>\n\n            </div>\n\n        </div>\n\n        <!--<div class=\"row\">\n            <div class=\"col-sm-12\">\n               <div class=\"footer-facebook-container\">\n                   <a target=\"_blank\" href=\"https://www.facebook.com/randopedia.net\"><img src=\"images/facebook_round_logo.png\" alt=\"Visit us on facebook\" width=\"40\" height=\"40\"></a>\n               </div>\n            </div>\n        </div>-->\n\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <ul class=\"inline-list\">\n                    <li class=\"green\">[Ski de randonnee] </li>\n                    <li class=\"red\">[Ski touren] </li>\n                    <li class=\"brown\">[Esqui de travesia] </li>\n                    <li class=\"blue\">[Ski touring] </li>\n                    <li class=\"green\">[Topptur] </li>\n                    <li class=\"red\">[Sci alpinismo]</li>\n                </ul>\n            </div>\n        </div>\n\n        <!--<div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div class=\"randopedia-logo-text\">Randopedia</div>\n            </div>\n        </div>-->\n\n    </div>\n</footer>");
  
});

Ember.TEMPLATES["gpx-file-upload-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', escapeExpression=this.escapeExpression;


  data.buffer.push("<!--  \n    View that wraps the javascript file uploader. The original UI is hidden\n -->\n \n<input type=\"file\" id=\"gpxFileInputElement\" accept=\".gpx\" class=\"hide\" />\n<div class=\"btn-group\">\n    <button class=\"btn btn-default btn-lg\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "openFileDialog", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n        <span class=\"glyphicon glyphicon-import\"></span> Select GPX file to import\n    </button>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["header"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n                <li class=\"dropdown\">\n                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\">Tours<span class=\"caret\"></span></a>\n                    <ul class=\"dropdown-menu\" role=\"menu\">\n                        <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "topbarmenulink", "tour.new", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","STRING"],data:data})));
  data.buffer.push(">Add new tour</a></li>\n                        <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "topbarmenulink", "mytours", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","STRING"],data:data})));
  data.buffer.push(">View my tours</a></li>\n                    </ul>\n                </li>\n                <li class=\"dropdown\">\n                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\">User<span class=\"caret\"></span></a>\n                    <ul class=\"dropdown-menu\" role=\"menu\">\n                        <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "logout", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Logout</a></li>\n                        <li class=\"divider\"></li>\n                        <li><p>Logged in as ");
  data.buffer.push(escapeExpression((helper = helpers.maxString || (depth0 && depth0.maxString),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["ID","INTEGER"],data:data},helper ? helper.call(depth0, "controllers.login.currentUser.userName", 50, options) : helperMissing.call(depth0, "maxString", "controllers.login.currentUser.userName", 50, options))));
  data.buffer.push("</p></li>\n                    </ul>\n                </li>\n                ");
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "topbarmenulink", "collapseNavbar", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","STRING"],data:data})));
  data.buffer.push(" data-toggle=\"modal\" data-target=\"#loginViewModalId\">Login</a></li>\n                ");
  return buffer;
  }

function program5(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n                <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "topbarmenulink", "tour.new", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","STRING"],data:data})));
  data.buffer.push(">Add new tour</a></li>\n                <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "topbarmenulink", "mytours", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","STRING"],data:data})));
  data.buffer.push(">View my tours</a></li>\n                <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "logout", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Logout</a></li>\n                <li class=\"divider\"></li>\n                <li><p>Logged in as ");
  data.buffer.push(escapeExpression((helper = helpers.maxString || (depth0 && depth0.maxString),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["ID","INTEGER"],data:data},helper ? helper.call(depth0, "controllers.login.currentUser.userName", 50, options) : helperMissing.call(depth0, "maxString", "controllers.login.currentUser.userName", 50, options))));
  data.buffer.push("</p></li>\n                ");
  return buffer;
  }

function program7(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n     ");
  data.buffer.push(escapeExpression((helper = helpers['search-component'] || (depth0 && depth0['search-component']),options={hash:{
    'store': ("store")
  },hashTypes:{'store': "ID"},hashContexts:{'store': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "search-component", options))));
  data.buffer.push("\n");
  return buffer;
  }

  data.buffer.push("<nav class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">\n    <div class=\"container-fluid\">\n        <div class=\"navbar-header\">\n            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">\n                <span class=\"sr-only\">Toggle navigation</span>\n                <span class=\"icon-bar\"></span>\n                <span class=\"icon-bar\"></span>\n                <span class=\"icon-bar\"></span>\n            </button>\n            <a class=\"navbar-brand randopedia-logo-text\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "gotoindex", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Randopedia</a>\n            <a class=\"navbar-search-button hidden-sm hidden-md hidden-lg\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleNavbarSearchbox", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("\">\n                <span class=\"glyphicon glyphicon-search\"></span>\n            </a>\n        </div>\n\n        <div id=\"navbar\" class=\"navbar-collapse collapse\">\n            <ul class=\"nav navbar-nav nav-with-space\">\n                <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "topbarmenulink", "index", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","STRING"],data:data})));
  data.buffer.push(">Map</a></li>\n                <li><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "topbarmenulink", "about", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","STRING"],data:data})));
  data.buffer.push(" data-toggle=\"collapse\" data-target=\".nav-collapse\">About</a></li>\n            </ul>\n\n            <ul class=\"nav navbar-nav hidden-xs\">\n                ");
  stack1 = helpers['if'].call(depth0, "controllers.login.isLoggedIn", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n            </ul>\n\n            <ul class=\"nav navbar-nav hidden-sm hidden-md hidden-lg\">\n                ");
  stack1 = helpers['if'].call(depth0, "controllers.login.isLoggedIn", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(5, program5, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n            </ul>\n\n            <ul class=\"nav navbar-nav navbar-right hidden-xs\">\n                <li>\n                    <a class=\"navbar-search-button pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "toggleNavbarSearchbox", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("\">\n                        <span class=\"glyphicon glyphicon-search\"></span>\n                    </a>\n                </li>\n            </ul>\n        </div>\n    </div>\n</nav>\n\n");
  stack1 = helpers['if'].call(depth0, "showNavbarSearch", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(7, program7, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" \n\n<div class=\"modal fade\" id=\"loginViewModalId\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">\n    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.LoginModalView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["image-carousel-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n<a class=\"left carousel-control\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "previousSlide", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-chevron-left\"></span></a>\n<a class=\"right carousel-control\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "nextSlide", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-chevron-right\"></span></a>\n");
  return buffer;
  }

  data.buffer.push(escapeExpression(helpers.view.call(depth0, "view.itemsView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n\n");
  stack1 = helpers['if'].call(depth0, "view.haveMoreThanOneImage", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("  ");
  return buffer;
  
});

Ember.TEMPLATES["index"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n    <div id=\"full-screen-map-container\" class=\"full-screen\">\n        ");
  data.buffer.push(escapeExpression((helper = helpers['browse-tourmap'] || (depth0 && depth0['browse-tourmap']),options={hash:{
    'store': ("store"),
    'tours': ("liteTours"),
    'zoomLevel': ("currentMapZoomLevel"),
    'mapCenter': ("currentMapCenter"),
    'tour': ("tourForMapView"),
    'zoomChanged': ("mapZoomChanged"),
    'centerChanged': ("mapCenterChanged")
  },hashTypes:{'store': "ID",'tours': "ID",'zoomLevel': "ID",'mapCenter': "ID",'tour': "ID",'zoomChanged': "STRING",'centerChanged': "STRING"},hashContexts:{'store': depth0,'tours': depth0,'zoomLevel': depth0,'mapCenter': depth0,'tour': depth0,'zoomChanged': depth0,'centerChanged': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "browse-tourmap", options))));
  data.buffer.push("\n    </div>\n");
  return buffer;
  }

function program3(depth0,data) {
  
  
  data.buffer.push("\n    <div class=\"loading\">Loading map...</div>\n");
  }

  data.buffer.push("\n");
  stack1 = helpers['if'].call(depth0, "liteTours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n\n\n\n");
  return buffer;
  
});

Ember.TEMPLATES["loading"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  


  data.buffer.push("<div class=\"loading\">Loading Randopedia...</div>");
  
});

Ember.TEMPLATES["login-modal-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', escapeExpression=this.escapeExpression;


  data.buffer.push("<div class=\"modal-dialog login-view\">\n    <div class=\"modal-content\">\n        <div class=\"modal-header\">\n            <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n            <h4 class=\"modal-title\" id=\"myModalLabel\">Select account to login with</h4>\n        </div>\n        <div class=\"modal-body\">\n            <a class=\"login-link\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "loginWithFacebook", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                <div>\n                Login with <img src=\"images/facebook_logo.png\">\n                </div>\n            </a>\n\n            <a class=\"login-link\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "loginWithGoogle", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                <div>\n                Login with <img src=\"images/google_logo.png\" width=\"100\">\n                </div>\n            </a>\n\n        </div>\n        <hr />\n        <div class=\"spacing\">\n	        <small>\n	            Randopedia doesn't use or store any sensitive information about the account being used. Read more about privacy <a data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "goToAbout", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">here</a>.\n	        </small>\n        </div>\n    </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["loginCallback"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, self=this;

function program1(depth0,data) {
  
  
  data.buffer.push("\n    Connecting to your facebook account...<img src=\"images/ajax-loader.gif\"/>\n");
  }

function program3(depth0,data) {
  
  
  data.buffer.push("\n    You're logged in\n");
  }

  stack1 = helpers['if'].call(depth0, "registering", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n<!-- \nLogin and authentication\nPattern from facebook (https://developers.facebook.com/docs/facebook-login/access-tokens/)\nClient requests token (login page i randopedia)\nIf successfull the client now has a valid facebook token\nThe client tells the server, our rest api, about this token\nCan be some kind of registering page\nStore user and user id in database\nMaybe best to have a user model server side and let server communicate with facebook\n(as in the pattern on facebook)\nSteps (not logged in scenario)\n1. User clicks login\n2. Auth request to facebook, user enters creds in popup\n3. Callback from facebook with\n -->\n");
  return buffer;
  
});

Ember.TEMPLATES["menu"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  


  data.buffer.push("<div class=\"row row-offcanvas row-offcanvas-left\">\n                      \n          \n            <!-- sidebar -->\n            <div class=\"column col-sm-2 col-xs-1 sidebar-offcanvas\" id=\"sidebar\">\n              \n              	<ul class=\"nav\">\n          			<li><a href=\"#\" data-toggle=\"offcanvas\" class=\"visible-xs text-center\"><i class=\"glyphicon glyphicon-chevron-right\"></i></a></li>\n            	</ul>\n               \n                <ul class=\"nav hidden-xs\" id=\"lg-menu\">\n                    <li class=\"active\"><a href=\"#featured\"><i class=\"glyphicon glyphicon-list-alt\"></i> Featured</a></li>\n                    <li><a href=\"#stories\"><i class=\"glyphicon glyphicon-list\"></i> Stories</a></li>\n                    <li><a href=\"#\"><i class=\"glyphicon glyphicon-paperclip\"></i> Saved</a></li>\n                    <li><a href=\"#\"><i class=\"glyphicon glyphicon-refresh\"></i> Refresh</a></li>\n                </ul>\n                <ul class=\"list-unstyled hidden-xs\" id=\"sidebar-footer\">\n                    <li>\n                      <a href=\"http://www.bootply.com\"><h3>Bootstrap</h3> <i class=\"glyphicon glyphicon-heart-empty\"></i> Bootply</a>\n                    </li>\n                </ul>\n              \n              	<!-- tiny only nav-->\n              <ul class=\"nav visible-xs\" id=\"xs-menu\">\n                  	<li><a href=\"#featured\" class=\"text-center\"><i class=\"glyphicon glyphicon-list-alt\"></i></a></li>\n                    <li><a href=\"#stories\" class=\"text-center\"><i class=\"glyphicon glyphicon-list\"></i></a></li>\n                  	<li><a href=\"#\" class=\"text-center\"><i class=\"glyphicon glyphicon-paperclip\"></i></a></li>\n                    <li><a href=\"#\" class=\"text-center\"><i class=\"glyphicon glyphicon-refresh\"></i></a></li>\n                </ul>\n              \n            </div>\n</div>");
  
});

Ember.TEMPLATES["mytours"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  data.buffer.push("\n                    <div class=\"loading\">Loading tours...</div>\n                    ");
  }

function program3(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n\n                    <div class=\"alert alert-info\" role=\"alert\">\n                        Below are all your tour drafts listed. These tours are only visible to you. You currently have ");
  stack1 = helpers._triageMustache.call(depth0, "drafts.length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" tour draft(s).\n                    </div>\n\n                    ");
  stack1 = helpers.each.call(depth0, "tour", "in", "drafts", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourItemView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                    ");
  return buffer;
  }

function program6(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n\n                    <div class=\"alert alert-info\" role=\"alert\">\n                        Below are all tours that you have created and/or made updates on listed. You have contributed on ");
  stack1 = helpers._triageMustache.call(depth0, "updates.length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" tour(s).\n                    </div>\n\n                    ");
  stack1 = helpers.each.call(depth0, "tour", "in", "updates", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                    ");
  return buffer;
  }

function program8(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n\n                    <div class=\"alert alert-info\" role=\"alert\">\n                        Below are all tours (not just yours) that currently are in review listed. There are currently ");
  stack1 = helpers._triageMustache.call(depth0, "reviews.length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" tour(s) in review.\n                    </div>\n\n                    ");
  stack1 = helpers.each.call(depth0, "tour", "in", "reviews", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                    ");
  return buffer;
  }

  data.buffer.push("<div class=\"container-fluid\">\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n\n            <ul class=\"nav nav-tabs\" role=\"tablist\">\n                <li class=\"active\"><a href=\"#drafts\" role=\"tab\" data-toggle=\"tab\">Drafts</a></li>\n                <li><a href=\"#updates\" role=\"tab\" data-toggle=\"tab\">Publications</a></li>\n                <li><a href=\"#reviews\" role=\"tab\" data-toggle=\"tab\">In review</a></li>\n            </ul>\n\n            <div class=\"tab-content\">\n                <div class=\"tab-pane active\" id=\"drafts\">\n\n                    ");
  stack1 = helpers['if'].call(depth0, "isLoadingDrafts", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                </div>\n\n                <div id=\"updates\" class=\"tab-pane\">\n\n                    ");
  stack1 = helpers['if'].call(depth0, "isLoadingUpdates", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(6, program6, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                </div>\n\n                <div id=\"reviews\" class=\"tab-pane\">\n\n                    ");
  stack1 = helpers['if'].call(depth0, "isLoadingReviews", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(8, program8, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                </div>\n            </div>\n        </div>\n    </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["components/search-component"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourItemView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n");
  return buffer;
  }

  data.buffer.push("\n");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.SearchTextField", {hash:{
    'valueBinding': ("query")
  },hashTypes:{'valueBinding': "STRING"},hashContexts:{'valueBinding': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n");
  stack1 = helpers.each.call(depth0, "tour", "in", "tours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n");
  return buffer;
  
});

Ember.TEMPLATES["search"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n	    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourItemView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n	");
  return buffer;
  }

  data.buffer.push("<div class=\"container-fluid\">\n\n	<div class=\"row\">\n	    <div class=\"col-sm-12\">\n	        <span class=\"pull-right spacing\"><a ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "clearResult", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Clear</a></span>\n			<h3>\n			    Tour search<span class=\"small text-nowrap\"> (");
  stack1 = helpers._triageMustache.call(depth0, "length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" tours found)</span>\n			</h3>\n	    </div>\n	</div> \n	\n	");
  stack1 = helpers.each.call(depth0, "tour", "in", "controller", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n</div>\n");
  return buffer;
  
});

Ember.TEMPLATES["stats"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1;


  data.buffer.push("<div class=\"container-fluid\">\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n            <div class=\"table-responsive\">\n                <table class=\"table table-striped\">\n                    <thead>\n                        <tr>\n                            <th width=\"250\">Stat</th>\n                            <th>Value</th>\n                        </tr>\n                    </thead>\n                    <tbody>\n                        <tr>\n                            <td>Published tours</td>\n                            <td>");
  stack1 = helpers._triageMustache.call(depth0, "publishedTours", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</td>\n                        </tr>\n                        <tr>\n                            <td>Published areas</td>\n                            <td>");
  stack1 = helpers._triageMustache.call(depth0, "publishedAreas", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</td>\n                        </tr>\n                        <tr>\n                            <td>Areas with no tours or sub areas</td>\n                            <td>");
  stack1 = helpers._triageMustache.call(depth0, "deadAreas", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</td>\n                        </tr>\n                        <tr>\n                            <td>Drafts</td>\n                            <td>");
  stack1 = helpers._triageMustache.call(depth0, "tourDrafts", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</td>\n                        </tr>\n                        <tr>\n                            <td>Registered users</td>\n                            <td>");
  stack1 = helpers._triageMustache.call(depth0, "registeredUsers", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</td>\n                        </tr>\n                    </tbody>\n                </table>\n            </div>\n\n        </div>\n    </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["tag"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  data.buffer.push("\n        <div class=\"loading\"></div>\n    ");
  }

function program3(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n        ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourItemView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n    ");
  return buffer;
  }

  data.buffer.push("<div class=\"container-fluid\">\n\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n            <h3>\n                #");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n            </h3>\n        </div>\n    </div>\n\n    ");
  stack1 = helpers['if'].call(depth0, "content.isUpdating", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n    ");
  stack1 = helpers.each.call(depth0, "tour", "in", "tours", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(3, program3, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["tags"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n        ");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(2, program2, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "tag", "tag", options) : helperMissing.call(depth0, "link-to", "tag", "tag", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n    ");
  return buffer;
  }
function program2(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("#");
  stack1 = helpers._triageMustache.call(depth0, "tag.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  return buffer;
  }

  data.buffer.push("<div class=\"container-fluid\">\n\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n            <h3>\n                Here are the top tags for randopedia.net\n            </h3>\n        </div>\n    </div>\n\n    ");
  stack1 = helpers.each.call(depth0, "tag", "in", "controller", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n</div>\n\n");
  return buffer;
  
});

Ember.TEMPLATES["tour"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var escapeExpression=this.escapeExpression;


  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourDetailsView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  
});

Ember.TEMPLATES["tourdetails-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helper, options, self=this, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  
  data.buffer.push("\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div class=\"alert alert-info alert-dismissible\" role=\"alert\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    This tour is a draft, it has not yet been published\n                </div>\n            </div>\n        </div>\n        ");
  }

function program3(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n            ");
  stack1 = helpers['if'].call(depth0, "isInReview", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n            ");
  stack1 = helpers['if'].call(depth0, "isIncomplete", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(6, program6, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n\n            ");
  stack1 = helpers['if'].call(depth0, "isDeleted", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(8, program8, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n        ");
  return buffer;
  }
function program4(depth0,data) {
  
  
  data.buffer.push("\n            <div class=\"row\">\n                <div class=\"col-sm-12\">\n                    <div class=\"alert alert-info alert-dismissible\" role=\"alert\">\n                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                        This tour is in review, it has not yet been published\n                    </div>\n                </div>\n            </div>\n            ");
  }

function program6(depth0,data) {
  
  
  data.buffer.push("\n            <div class=\"row\">\n                <div class=\"col-sm-12\">\n                    <div class=\"alert alert-warning\" role=\"alert\">\n                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                        This tour is marked as incomplete so it might lack some important information\n                    </div>\n                </div>\n            </div>\n            ");
  }

function program8(depth0,data) {
  
  
  data.buffer.push("\n            <div class=\"row\">\n                <div class=\"col-sm-12\">\n                    <div class=\"alert alert-danger\" role=\"alert\">\n                        <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                        Tour is marked as deleted and will eventually be permanently deleted from the database\n                    </div>\n                </div>\n            </div>\n            ");
  }

function program10(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push(" <span class=\"small\">(");
  stack1 = helpers._triageMustache.call(depth0, "elevationMax", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("m)</span> ");
  return buffer;
  }

function program12(depth0,data) {
  
  
  data.buffer.push("\n                    <span class=\"small\">\n                        <a title=\"Tour is marked as incomplete\" class=\"default-cursor\">\n                            <span class=\"glyphicon glyphicon-warning-sign danger\"></span>\n                        </a>\n                    </span>\n                    ");
  }

function program14(depth0,data) {
  
  var stack1;
  stack1 = helpers._triageMustache.call(depth0, "timingMin", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  else { data.buffer.push(''); }
  }

function program16(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("-");
  stack1 = helpers._triageMustache.call(depth0, "timingMax", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  return buffer;
  }

function program18(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                        ");
  stack1 = helpers._triageMustache.call(depth0, "elevationGain", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("m &uarr;\n                        ");
  return buffer;
  }

function program20(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                        ");
  stack1 = helpers._triageMustache.call(depth0, "elevationLoss", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("m &darr;\n                        ");
  return buffer;
  }

function program22(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n                <div class=\"row\">\n                    <div class=\"col-xs-5 col-sm-3 col-lg-2\">\n                        <label>Grade:</label>\n                    </div>\n                    <div class=\"col-xs-7 col-sm-9 col-lg-10\">\n                        <a data-toggle=\"modal\" data-target=\"#tourDetailsGradeGuideModal\">");
  data.buffer.push(escapeExpression((helper = helpers.resolveGradeName || (depth0 && depth0.resolveGradeName),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "grade", options) : helperMissing.call(depth0, "resolveGradeName", "grade", options))));
  data.buffer.push("</a>\n                    </div>\n                </div>\n                ");
  return buffer;
  }

function program24(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                <div class=\"row\">\n                    <div class=\"col-xs-5 col-sm-3 col-lg-2\">\n                        <label>Steepness:</label>\n                    </div>\n                    <div class=\"col-xs-7 col-sm-9 col-lg-10\">\n                        ");
  stack1 = helpers._triageMustache.call(depth0, "degreesMax", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("&#176;\n                    </div>\n                </div>\n                ");
  return buffer;
  }

function program26(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                ");
  stack1 = helpers['if'].call(depth0, "timeOfYearTo", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(27, program27, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                ");
  return buffer;
  }
function program27(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n                <div class=\"row\">\n                    <div class=\"col-xs-5 col-sm-3 col-sm-3 col-lg-2\">\n                        <label>Season:</label>\n                    </div>\n                    <div class=\"col-xs-7 col-sm-9 col-lg-10\">\n                        ");
  data.buffer.push(escapeExpression((helper = helpers.resolveMonthName || (depth0 && depth0.resolveMonthName),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "timeOfYearFrom", options) : helperMissing.call(depth0, "resolveMonthName", "timeOfYearFrom", options))));
  data.buffer.push(" - ");
  data.buffer.push(escapeExpression((helper = helpers.resolveMonthName || (depth0 && depth0.resolveMonthName),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "timeOfYearTo", options) : helperMissing.call(depth0, "resolveMonthName", "timeOfYearTo", options))));
  data.buffer.push("\n                    </div>\n                </div>\n                ");
  return buffer;
  }

function program29(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n                <div class=\"row\">\n                    <div class=\"col-xs-5 col-sm-3 col-lg-2\">\n                        <label>Aspect:</label>\n                    </div>\n                    <div class=\"col-xs-7 col-sm-9 col-lg-10\">\n                        ");
  data.buffer.push(escapeExpression((helper = helpers.resolveAspectName || (depth0 && depth0.resolveAspectName),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "aspect", options) : helperMissing.call(depth0, "resolveAspectName", "aspect", options))));
  data.buffer.push("\n                    </div>\n                </div>\n                ");
  return buffer;
  }

function program31(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                <div class=\"row\">\n                    <div class=\"col-xs-5 col-sm-3 col-lg-2\">\n                        <label>Tags:</label>\n                    </div>\n                    <div class=\"col-xs-7 col-sm-9 col-lg-10\">\n                        ");
  stack1 = helpers.each.call(depth0, "tag", "in", "tags", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(32, program32, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    </div>\n                </div>\n                ");
  return buffer;
  }
function program32(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n                            ");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(33, program33, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "tag", "tag", options) : helperMissing.call(depth0, "link-to", "tag", "tag", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                        ");
  return buffer;
  }
function program33(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push(" #");
  stack1 = helpers._triageMustache.call(depth0, "tag", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" ");
  return buffer;
  }

function program35(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                        ");
  stack1 = helpers['if'].call(depth0, "hasMapData", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(36, program36, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                        ");
  stack1 = helpers['if'].call(depth0, "hasPaths", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(38, program38, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program36(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                            <button class=\"btn btn-primary\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "viewTourOnMap", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                                <span class=\"glyphicon glyphicon-globe\"></span> View tour on map\n                            </button>\n                        ");
  return buffer;
  }

function program38(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                            <button class=\"btn btn-primary\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "downloadGpxFile", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                                <span class=\"glyphicon glyphicon-export\"></span> GPX\n                            </button>\n                        ");
  return buffer;
  }

function program40(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                        ");
  stack1 = helpers['if'].call(depth0, "hasMapData", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(41, program41, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program41(depth0,data) {
  
  
  data.buffer.push("\n                            <div class=\"spacing\">[View tour on map] <em>Tours are not available on the map until they are published.</em></div>\n                        ");
  }

function program43(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n            <div class=\"col-sm-12 col-sm-6\">\n                <div class=\"panel panel-danger\">\n                    <div class=\"panel-heading\">Hazards</div>\n                    <div class=\"panel-body\">\n                        ");
  stack1 = helpers._triageMustache.call(depth0, "hazardsDescription", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    </div>\n                </div>\n            </div>\n            ");
  return buffer;
  }

function program45(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n            <div class=\"col-sm-12 col-sm-6\">\n                <div class=\"panel panel-info\">\n                    <div class=\"panel-heading\">Mountaineering</div>\n                    <div class=\"panel-body\">\n                        ");
  stack1 = helpers._triageMustache.call(depth0, "toolsDescription", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    </div>\n                </div>\n            </div>\n            ");
  return buffer;
  }

function program47(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.ImageCarouselView", {hash:{
    'contentBinding': ("images")
  },hashTypes:{'contentBinding': "STRING"},hashContexts:{'contentBinding': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                ");
  return buffer;
  }

function program49(depth0,data) {
  
  
  data.buffer.push("\n                <div class=\"spacing-x-large spacing-y\">No images available for this tour</div>\n                ");
  }

function program51(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div class=\"panel-group spacing-y-large\" id=\"accordion\">\n                    <div class=\"panel panel-default\">\n                        <div class=\"panel-heading\">\n                            <a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\">\n                                Discussions and trip reports\n                            </a>\n                        </div>\n                        <div id=\"collapseOne\" class=\"panel-collapse collapse in\">\n                            <div class=\"panel-body\">\n                                ");
  stack1 = helpers._triageMustache.call(depth0, "disqus-component", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                            </div>\n                        </div>\n                    </div>\n                </div>\n             </div>\n        </div>\n        ");
  return buffer;
  }

function program53(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n            ");
  stack1 = helpers['if'].call(depth0, "controllers.login.isLoggedIn", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(54, program54, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n        ");
  return buffer;
  }
function program54(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                <div class=\"row\">\n                    <div class=\"col-sm-12\">\n                        <div class=\"panel-group spacing-y-large\" id=\"accordion\">\n                            <div class=\"panel panel-default\">\n                                <div class=\"panel-heading\">\n                                    <a class=\"accordion-toggle\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\">\n                                        Review comments (");
  stack1 = helpers._triageMustache.call(depth0, "comments.length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(")\n                                    </a>\n                                </div>\n                                <div id=\"collapseOne\" class=\"panel-collapse collapse in\">\n                                    <div class=\"panel-body\">\n                                        ");
  stack1 = helpers.each.call(depth0, "comments", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(55, program55, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                                    </div>\n                                    <div class=\"panel-footer\">\n                                        <button class=\"btn btn-primary\" data-toggle=\"modal\" data-target=\"#addReviewCommentModal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "startAddReviewComment", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                                            <span class=\"glyphicon glyphicon-plus\"></span> Add comment\n                                        </button>\n                                    </div>\n                                </div>\n                            </div>\n                         </div>\n                    </div>\n                </div>\n            ");
  return buffer;
  }
function program55(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n                                        <div class=\"spacing-y\">\n                                            ");
  stack1 = helpers._triageMustache.call(depth0, "comment", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                                            <div class=\"secondary-text\">\n                                                ");
  stack1 = helpers._triageMustache.call(depth0, "userName", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" - ");
  data.buffer.push(escapeExpression((helper = helpers.displayTimestamp || (depth0 && depth0.displayTimestamp),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "time", options) : helperMissing.call(depth0, "displayTimestamp", "time", options))));
  data.buffer.push("\n                                            </div>\n                                        </div>\n                                        <hr />\n                                        ");
  return buffer;
  }

function program57(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n        <div class=\"row\">\n            <div class=\"col-sm-12 edit-container\">\n                ");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(58, program58, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "tour.edit", "model", options) : helperMissing.call(depth0, "link-to", "tour.edit", "model", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n            </div>\n        </div>\n        ");
  return buffer;
  }
function program58(depth0,data) {
  
  
  data.buffer.push("<span class=\"glyphicon glyphicon-edit\"></span> Edit tour");
  }

  data.buffer.push("<div class=\"container-fluid\">\n    <div class=\"tour-details-view\">\n\n        <div class=\"hidden\">");
  stack1 = helpers._triageMustache.call(depth0, "view.imageLoaded", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</div>\n\n        ");
  stack1 = helpers['if'].call(depth0, "isDraft", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <ul class=\"inline-list\">\n                    ");
  data.buffer.push(escapeExpression((helper = helpers['area-breadcrumb'] || (depth0 && depth0['area-breadcrumb']),options={hash:{
    'area': ("area")
  },hashTypes:{'area': "ID"},hashContexts:{'area': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "area-breadcrumb", options))));
  data.buffer.push("\n                </ul>\n            </div>\n        </div>\n\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <h2>\n                    ");
  stack1 = helpers._triageMustache.call(depth0, "name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" ");
  stack1 = helpers['if'].call(depth0, "elevationMax", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(10, program10, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                    ");
  stack1 = helpers['if'].call(depth0, "isIncomplete", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(12, program12, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                </h2>\n            </div>\n        </div>\n\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <em>");
  stack1 = helpers._triageMustache.call(depth0, "shortDescription", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</em>\n            </div>\n        </div>\n\n        <div class=\"row tour-props\">\n            <div class=\"col-sm-12 col-lg-6\">\n\n                <div class=\"row\">\n                    <div class=\"col-xs-5 col-sm-3 col-lg-2\">\n                        <label>Time:</label>\n                    </div>\n                    <div class=\"col-xs-7 col-sm-9 col-lg-10\">\n                        ");
  stack1 = helpers['if'].call(depth0, "timingMin", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(14, program14, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  stack1 = helpers['if'].call(depth0, "timingMax", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(16, program16, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("h\n                    </div>\n                </div>\n\n                <div class=\"row\">\n                    <div class=\"col-xs-5 col-sm-3 col-lg-2\">\n                        <label>Elevation:</label>\n                    </div>\n                    <div class=\"col-xs-7 col-sm-9 col-lg-10\">\n                        ");
  stack1 = helpers['if'].call(depth0, "elevationGain", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(18, program18, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                        ");
  stack1 = helpers['if'].call(depth0, "elevationLoss", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(20, program20, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    </div>\n                </div>\n\n                ");
  stack1 = helpers['if'].call(depth0, "grade", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(22, program22, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                ");
  stack1 = helpers['if'].call(depth0, "degreesMax", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(24, program24, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                ");
  stack1 = helpers['if'].call(depth0, "timeOfYearFrom", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(26, program26, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                ");
  stack1 = helpers['if'].call(depth0, "aspect", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(29, program29, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                ");
  stack1 = helpers['if'].call(depth0, "tags", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(31, program31, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n            </div>\n\n        </div>\n\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div class=\"map-buttons-container\">\n                    ");
  stack1 = helpers['if'].call(depth0, "isPublished", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(40, program40, data),fn:self.program(35, program35, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                </div>\n            </div>\n\n            <div class=\"col-sm-12\">\n                <div class=\"panel panel-default\">\n                    <div class=\"panel-heading\">Access point</div>\n                    <div class=\"panel-body\">\n                        ");
  stack1 = helpers._triageMustache.call(depth0, "accessPoint", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div class=\"panel panel-default\">\n                    <div class=\"panel-heading\">Description</div>\n                    <div class=\"panel-body\">\n                        <div>");
  data.buffer.push(escapeExpression(helpers._triageMustache.call(depth0, "markedItinerary", {hash:{
    'unescaped': ("true")
  },hashTypes:{'unescaped': "STRING"},hashContexts:{'unescaped': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("</div>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"row\">\n            ");
  stack1 = helpers['if'].call(depth0, "haveHazards", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(43, program43, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n            ");
  stack1 = helpers['if'].call(depth0, "requiresTools", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(45, program45, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n        </div>\n\n        <div class=\"row\">\n            <div id=\"image-carousel-container\" class=\"image-carousel-container col-sm-12\">\n\n                <h4>Images<span class=\"small\"> (");
  stack1 = helpers._triageMustache.call(depth0, "images.length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(")</span></h4>\n\n                ");
  stack1 = helpers['if'].call(depth0, "hasImages", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(49, program49, data),fn:self.program(47, program47, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n\n            </div>\n        </div>\n\n        ");
  stack1 = helpers['if'].call(depth0, "isPublished", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(51, program51, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n        ");
  stack1 = helpers['if'].call(depth0, "isInReview", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(53, program53, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n        ");
  stack1 = helpers['if'].call(depth0, "controllers.login.isLoggedIn", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(57, program57, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n        ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "footer", options) : helperMissing.call(depth0, "partial", "footer", options))));
  data.buffer.push("\n\n        <div class=\"modal fade\" id=\"tourDetailsGradeGuideModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">\n            <div class=\"modal-dialog modal-lg\">\n                <div class=\"modal-content\">\n                    <div class=\"modal-header\">\n                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                        <h4 class=\"modal-title\" id=\"myModalLabel\">Grades</h4>\n                    </div>\n                    <div class=\"modal-body\">\n                        ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "about-grades", options) : helperMissing.call(depth0, "partial", "about-grades", options))));
  data.buffer.push("\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"modal fade\" id=\"addReviewCommentModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n            <div class=\"modal-dialog modal-lg\">\n                <div class=\"modal-content\">\n                    <div class=\"modal-header\">\n                        <h4 class=\"modal-title\">Add review comment</h4>\n                    </div>\n                    <div class=\"modal-body\">\n                        <form role=\"form\">\n                            <label for=\"commentField\">Comment</label>\n                            ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'value': ("newCommentText"),
    'maxlength': (500),
    'class': ("form-control"),
    'id': ("commentField")
  },hashTypes:{'value': "ID",'maxlength': "INTEGER",'class': "STRING",'id': "STRING"},hashContexts:{'value': depth0,'maxlength': depth0,'class': depth0,'id': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n                        </form>\n                    </div>\n                    <div class=\"modal-footer\">\n                        <button ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "cancelSaveReviewComment", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(" data-dismiss=\"modal\" class=\"btn btn-default pull-right\">Cancel</button>\n                        <button ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "saveReviewComment", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(" data-dismiss=\"modal\" class=\"btn btn-primary pull-right\">Save</button>\n                    </div>\n                </div>\n            </div>\n        </div>\n\n    </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["touredit-images"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n	<div class=\"row\">\n	   <div class=\"col-sm-12\">\n	        <div class=\"panel\">\n	            <div class=\"row\">\n                    <hr />\n	                <div class=\"col-sm-12 col-lg-2\">\n                        <div class=\"thumbnail-wrapper\">\n                            <img ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'src': ("newImage.imageData")
  },hashTypes:{'src': "STRING"},hashContexts:{'src': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" />\n                        </div>\n	                </div>\n	                <div class=\"col-sm-12 col-lg-10\">\n                        <form class=\"form\">\n                            <div class=\"form-group\">\n                                <label>Caption</label>\n                                ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'value': ("newImage.caption"),
    'maxlength': ("300"),
    'class': ("form-control")
  },hashTypes:{'value': "ID",'maxlength': "STRING",'class': "STRING"},hashContexts:{'value': depth0,'maxlength': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                            </div>\n                            <div class=\"form-group\">\n                                <div class=\"button-group pull-right\">\n                                    <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "removeNewImage", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(" class=\"btn btn-default\">Cancel</button>\n                                    <button class=\"btn btn-primary\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "saveNewImage", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(" class=\"btn btn-primary\">Upload image</button>\n                                </div>                   \n                            </div>                         \n                        </form>\n	                </div>\n	            </div>\n	        </div>\n	     </div>\n	</div>\n	");
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n		    ");
  stack1 = helpers.unless.call(depth0, "image.isNew", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(4, program4, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n		");
  return buffer;
  }
function program4(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n	            <div class=\"col-sm-12\">\n                    <hr />\n	                <div class=\"row\">\n	                    <div class=\"col-sm-12 col-lg-2\">\n	                            <div class=\"thumbnail-wrapper\">\n	                            <img ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'src': ("image.imageFile")
  },hashTypes:{'src': "STRING"},hashContexts:{'src': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" class=\"thumbnail-image\" />\n	                        </div>\n	                    </div>\n	                    <div class=\"col-sm-12 col-lg-10\">\n	                        <form class=\"form\">\n	                            <div class=\"form-group\">\n		                            <label>Caption</label>\n                                    ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'value': ("image.caption"),
    'maxlength': ("300"),
    'class': ("form-control")
  },hashTypes:{'value': "ID",'maxlength': "STRING",'class': "STRING"},hashContexts:{'value': depth0,'maxlength': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                </div>\n                                <div class=\"form-group\">\n                                    <div class=\"checkbox\">\n										<label>\n										    ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'type': ("checkbox"),
    'name': ("isPorfolio"),
    'checked': ("image.isPortfolio")
  },hashTypes:{'type': "STRING",'name': "STRING",'checked': "ID"},hashContexts:{'type': depth0,'name': depth0,'checked': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push(" Is portfolio image\n										</label>\n										</div>\n										<div class=\"button-group pull-right\">\n		                                    <button ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "saveImage", "image", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0,depth0],types:["STRING","ID"],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("image.isUpdateDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" class=\"btn btn-primary\">Update</button>\n		                                    <button ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "startDeleteImage", "image", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0,depth0],types:["STRING","ID"],data:data})));
  data.buffer.push(" data-toggle=\"modal\" data-target=\"#confirmDeleteImageModal\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("image.isDeleteDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" class=\"btn btn-danger\">Delete image</button>\n		                                </div>\n                                </div>                                            \n                            </form>\n	                    </div>\n	                </div>\n	            </div>\n		    ");
  return buffer;
  }

  data.buffer.push("<!-- \n    Template for an image uploader with preview of selected images    \n-->\n<div class=\"image-upload-view\">\n\n	<div class=\"row\">\n	    <div class=\"col-sm-12\">\n	        <h4>Upload new images</h4>\n	    </div>\n	</div>\n	\n	<div class=\"row\">\n	    <div class=\"col-sm-12\">\n	        <div>");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.FileUploadView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("</div>\n	    </div>\n	</div>\n	\n	");
  stack1 = helpers['if'].call(depth0, "hasNewImage", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	\n	<div class=\"row\">\n	    <div class=\"col-sm-12\">\n	        <hr />\n	        <h4>Current tour images <span class=\"secondary-text\">(");
  stack1 = helpers._triageMustache.call(depth0, "images.length", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(")</span></h4>\n	    </div>\n	</div>\n		\n	<div class=\"row\">\n		<div class=\"col-sm-12\">\n		");
  stack1 = helpers.each.call(depth0, "image", "in", "images", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(3, program3, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n	    </div>         \n	</div>\n	\n    <div class=\"modal fade\" id=\"confirmDeleteImageModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Delete image</h4>\n                </div>\n                <div class=\"modal-body\">\n                    Are you sure you want to delete the image? It will not be possible to restore the image.\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-left\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-danger pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "confirmDeleteImage", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Delete image</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n</div>\n");
  return buffer;
  
});

Ember.TEMPLATES["touredit-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  data.buffer.push("\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n            <div class=\"alert alert-danger\" role=\"alert\">\n                <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                Couldn't save tour, area and name must be set.\n            </div>\n        </div>\n    </div>\n    ");
  }

function program3(depth0,data) {
  
  
  data.buffer.push("\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n            <div class=\"alert alert-info alert-dismissible\" role=\"alert\">\n                <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                This is a draft, the tour has not yet been published.\n            </div>\n        </div>\n    </div>\n    ");
  }

function program5(depth0,data) {
  
  
  data.buffer.push("\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n            <div class=\"alert alert-danger\" role=\"alert\">\n                <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                Tour is marked as deleted and will eventually be permanently deleted from the databse.\n            </div>\n        </div>\n    </div>\n    ");
  }

function program7(depth0,data) {
  
  
  data.buffer.push("Select area...");
  }

function program9(depth0,data) {
  
  var stack1;
  stack1 = helpers._triageMustache.call(depth0, "area.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  else { data.buffer.push(''); }
  }

function program11(depth0,data) {
  
  
  data.buffer.push("\n                                <p>Images cannot be uploaded until tour is saved. Please save tour and then come back!</p>\n                                ");
  }

function program13(depth0,data) {
  
  var buffer = '', helper, options;
  data.buffer.push("\n                                ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "touredit-images", options) : helperMissing.call(depth0, "partial", "touredit-images", options))));
  data.buffer.push("\n                                ");
  return buffer;
  }

function program15(depth0,data) {
  
  var buffer = '', stack1, helper, options;
  data.buffer.push("\n                                        <tr>\n                                            <td>");
  data.buffer.push(escapeExpression((helper = helpers.displayTimestamp || (depth0 && depth0.displayTimestamp),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "action.time", options) : helperMissing.call(depth0, "displayTimestamp", "action.time", options))));
  data.buffer.push("</td>\n                                            <td>");
  data.buffer.push(escapeExpression((helper = helpers.resolveTourAction || (depth0 && depth0.resolveTourAction),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "action.type", options) : helperMissing.call(depth0, "resolveTourAction", "action.type", options))));
  data.buffer.push("</td>\n                                            <td>");
  stack1 = helpers._triageMustache.call(depth0, "action.userName", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</td>\n                                            <td>");
  stack1 = helpers._triageMustache.call(depth0, "action.comment", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</td>\n                                        </tr>\n                                        ");
  return buffer;
  }

function program17(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                    <div class=\"alert alert-danger\" role=\"alert\">\n                        Tour data is invalid or incomplete\n                    </div>\n\n                    <div>\n                        <p>The tour lacks to much data to be published. Please add missing data and try again.</p>\n                        <p class=\"secondary-text\">\n                            The following fields are missing or invalid:\n                            ");
  stack1 = helpers.each.call(depth0, "error", "in", "validationErrors", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(18, program18, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                        </p>\n\n                        <p class=\"secondary-text confirmation-message\">\n                            Required fields for publish are: Area, Name, Access point, Description, Time min/max and Elevation gain/loss\n                        </p>\n                    </div>\n                    ");
  return buffer;
  }
function program18(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                            <code>");
  stack1 = helpers._triageMustache.call(depth0, "error", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</code>,\n                            ");
  return buffer;
  }

function program20(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                    ");
  stack1 = helpers['if'].call(depth0, "view.haveValidationWarnings", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(24, program24, data),fn:self.program(21, program21, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program21(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                    <div class=\"alert alert-warning\" role=\"alert\">\n                        Tour data is valid but incomplete\n                    </div>\n                    <div>\n                        <p>The tour lacks some important data. It can be published, but it'll be marked as incomplete.</p>\n\n                        <p class=\"secondary-text confirmation-message\">\n                            The following fields are missing:\n                            ");
  stack1 = helpers.each.call(depth0, "warning", "in", "validationWarnings", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(22, program22, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                        </p>\n                    </div>\n                    ");
  return buffer;
  }
function program22(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                            <code>");
  stack1 = helpers._triageMustache.call(depth0, "warning", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</code>,\n                            ");
  return buffer;
  }

function program24(depth0,data) {
  
  
  data.buffer.push("\n                    <div class=\"alert alert-success\" role=\"alert\">\n                        Tour data is valid\n                    </div>\n                    <p>Tour is ready to be published.</p>\n                    ");
  }

function program26(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                    <div class=\"btn-group pull-right\">\n                        <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("isSendToReviewDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "sendToReview", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                            <span class=\"glyphicon glyphicon-user\"></span> Send to review\n                        </button>\n                    </div>\n\n                    ");
  stack1 = helpers.unless.call(depth0, "isInReview", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(27, program27, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                ");
  return buffer;
  }
function program27(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                        <div class=\"btn-group pull-right\">\n                            <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("isSaveAsDraftDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "saveAsDraft", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                                <span class=\"glyphicon glyphicon-floppy-save\"></span> Save as draft\n                            </button>\n                        </div>\n                    ");
  return buffer;
  }

function program29(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                    ");
  stack1 = helpers['if'].call(depth0, "havePendingOperations", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(32, program32, data),fn:self.program(30, program30, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program30(depth0,data) {
  
  
  data.buffer.push("\n                    <span class=\"spacing-x-large\"><span class=\"glyphicon glyphicon-floppy-disk\"></span><em> Saving...</em></span>\n                    ");
  }

function program32(depth0,data) {
  
  
  data.buffer.push("\n                    <span class=\"spacing-x-large\"><span class=\"glyphicon glyphicon-floppy-disk\"></span><em class=\"hidden-xs\"> Tour has unsaved changes</em></span>\n                    ");
  }

  data.buffer.push("<div class=\"container-fluid tour-edit-view\">\n\n    ");
  stack1 = helpers['if'].call(depth0, "draftValidationErrors", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n    ");
  stack1 = helpers['if'].call(depth0, "isDraft", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(3, program3, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n    ");
  stack1 = helpers['if'].call(depth0, "isDeleted", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(5, program5, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n\n            <ul class=\"nav nav-tabs\" role=\"tablist\">\n                <li class=\"active\"><a href=\"#details-panel\" role=\"tab\" data-toggle=\"tab\">Details</a></li>\n                <li><a href=\"#itinerary-panel\" role=\"tab\" data-toggle=\"tab\">Description</a></li>\n                <li><a href=\"#map-panel\" role=\"tab\" data-toggle=\"tab\">Map</a></li>\n                <li><a href=\"#images-panel\" role=\"tab\" data-toggle=\"tab\">Images</a></li>\n                <li><a href=\"#history-panel\" role=\"tab\" data-toggle=\"tab\">History</a></li>\n            </ul>\n\n            <div class=\"tab-content\">\n                <div class=\"tab-pane active\" id=\"details-panel\">\n                    <form role=\"form\">\n\n                        <div class=\"row\">\n                            <div class=\"col-sm-4\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputArea\">Area<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\" title=\"Area\" data-content=\"The area where the tour is located.\"></button>\n                                    <div><a data-toggle=\"modal\" data-target=\"#areaPickerModal\">");
  stack1 = helpers.unless.call(depth0, "area", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(9, program9, data),fn:self.program(7, program7, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</a></div>\n                                </div>\n                            </div>\n                            <div class=\"col-sm-8\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputName\">Name of tour<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\"\n                                            class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\" title=\"Name\" data-content=\"The name of the tour. Name is required and must be between 3 and 80 characters long.\"></button>\n                                    ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'placeholder': (""),
    'pattern': ("^.{3,80}$"),
    'value': ("name"),
    'id': ("inputName"),
    'class': ("form-control")
  },hashTypes:{'placeholder': "STRING",'pattern': "STRING",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'placeholder': depth0,'pattern': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                </div>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-sm-12\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputShortDescription\">Tour summary<span class=\"asterisk recommended\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Tour summary\"\n                                            data-content=\"A brief description summarizing the highlights of the tour. Description can have a maximum of 500 characters.\"></button>\n                                    ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'maxlength': ("500"),
    'value': ("shortDescription"),
    'id': ("inputShortDescription"),
    'class': ("form-control")
  },hashTypes:{'maxlength': "STRING",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'maxlength': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                </div>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-sm-12 descTextAreaContainer\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputAccessPoint\">Access point<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Access point\"\n                                            data-content=\"Description of the access point and how to get there. The access point description can have a maximum of 1000 characters.\"></button>\n                                    ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'value': ("accessPoint"),
    'maxlength': ("1000"),
    'id': ("inputAccessPoint"),
    'class': ("form-control")
  },hashTypes:{'value': "ID",'maxlength': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'value': depth0,'maxlength': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n                                </div>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputElevationLoss\">Elevation loss<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Elevation loss\"\n                                            data-content=\"Total elevation to descend. Only digits are allowed.\"></button>\n                                    <div class=\"input-group\">\n                                        ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'placeholder': (""),
    'pattern': ("App.Validate.numberRegex"),
    'value': ("elevationLoss"),
    'id': ("inputElevationLoss"),
    'class': ("form-control")
  },hashTypes:{'placeholder': "STRING",'pattern': "ID",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'placeholder': depth0,'pattern': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                        <div class=\"input-group-addon\">m</div>\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=inputElevationGain\">Elevation gain<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Elevation gain\"\n                                            data-content=\"Total elevation to climb. Only digits are allowed.\"></button>\n                                    <div class=\"input-group\">\n                                        ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'placeholder': (""),
    'pattern': ("App.Validate.numberRegex"),
    'value': ("elevationGain"),
    'id': ("inputElevationGain"),
    'class': ("form-control")
  },hashTypes:{'placeholder': "STRING",'pattern': "ID",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'placeholder': depth0,'pattern': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                        <div class=\"input-group-addon\">m</div>\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputHighestPoint\">Highest point<span class=\"asterisk recommended\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Highest point\"\n                                            data-content=\"The highest point of the tour. Only digits are allowed.\"></button>\n                                    <div class=\"input-group\">\n                                        ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'placeholder': (""),
    'pattern': ("App.Validate.numberRegex"),
    'value': ("elevationMax"),
    'id': ("inputHighestPoint"),
    'class': ("form-control")
  },hashTypes:{'placeholder': "STRING",'pattern': "ID",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'placeholder': depth0,'pattern': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                        <div class=\"input-group-addon\">m</div>\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputAspect\">Main aspect of slopes</span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Aspect\"\n                                            data-content=\"Aspect of the main part of the slopes on the descent route.\"></button>\n                                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "Ember.Select", {hash:{
    'contentBinding': ("App.Fixtures.Aspects"),
    'optionValuePath': ("content.value"),
    'optionLabelPath': ("content.name"),
    'valueBinding': ("aspect"),
    'id': ("inputAspect"),
    'class': ("form-control")
  },hashTypes:{'contentBinding': "STRING",'optionValuePath': "STRING",'optionLabelPath': "STRING",'valueBinding': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'contentBinding': depth0,'optionValuePath': depth0,'optionLabelPath': depth0,'valueBinding': depth0,'id': depth0,'class': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                                </div>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputTimeMin\">Time, min<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Time min\"\n                                            data-content=\"The minimum amount of time that can be expected for the tour. Only digits are allowed.\"></button>\n                                    <div class=\"input-group\">\n                                        ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'placeholder': (""),
    'pattern': ("App.Validate.numberRegex"),
    'value': ("timingMin"),
    'id': ("inputTimeMin"),
    'class': ("form-control")
  },hashTypes:{'placeholder': "STRING",'pattern': "ID",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'placeholder': depth0,'pattern': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                        <div class=\"input-group-addon\">h</div>\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputTimeMax\">Time, max<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Time max\"\n                                            data-content=\"The maximum amount of time that can be expected for the tour. Only digits are allowed.\"></button>\n                                    <div class=\"input-group\">\n                                        ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'placeholder': (""),
    'pattern': ("App.Validate.numberRegex"),
    'value': ("timingMax"),
    'id': ("inputTimeMax"),
    'class': ("form-control")
  },hashTypes:{'placeholder': "STRING",'pattern': "ID",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'placeholder': depth0,'pattern': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                        <div class=\"input-group-addon\">h</div>\n                                    </div>\n                                </div>\n                            </div>\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputSeasonFrom\">Season from<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Season from\"\n                                            data-content=\"First month of the season when the tour normally is skiable.\"></button>\n                                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "Ember.Select", {hash:{
    'contentBinding': ("App.Fixtures.Months"),
    'optionValuePath': ("content.value"),
    'optionLabelPath': ("content.name"),
    'valueBinding': ("timeOfYearFrom"),
    'id': ("inputSeasonFrom"),
    'class': ("form-control")
  },hashTypes:{'contentBinding': "STRING",'optionValuePath': "STRING",'optionLabelPath': "STRING",'valueBinding': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'contentBinding': depth0,'optionValuePath': depth0,'optionLabelPath': depth0,'valueBinding': depth0,'id': depth0,'class': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                                </div>\n                            </div>\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputTimeOfYearTo\">Season to<span class=\"asterisk required\"></span></label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Season to\"\n                                            data-content=\"Last month of the season when the tour normally is skiable.\"></button>\n                                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "Ember.Select", {hash:{
    'contentBinding': ("App.Fixtures.Months"),
    'optionValuePath': ("content.value"),
    'optionLabelPath': ("content.name"),
    'valueBinding': ("timeOfYearTo"),
    'id': ("inputTimeOfYearTo"),
    'class': ("form-control")
  },hashTypes:{'contentBinding': "STRING",'optionValuePath': "STRING",'optionLabelPath': "STRING",'valueBinding': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'contentBinding': depth0,'optionValuePath': depth0,'optionLabelPath': depth0,'valueBinding': depth0,'id': depth0,'class': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                                </div>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputGrade\">Grade<span class=\"asterisk recommended\"></span></label>\n                                    <button class=\"info pull-right\" data-toggle=\"modal\" data-target=\"#tourDetailsGradeGuideModal\"></button>\n                                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "Ember.Select", {hash:{
    'contentBinding': ("App.Fixtures.Grades"),
    'optionValuePath': ("content.value"),
    'optionLabelPath': ("content.name"),
    'valueBinding': ("grade"),
    'id': ("inputGrade"),
    'class': ("form-control")
  },hashTypes:{'contentBinding': "STRING",'optionValuePath': "STRING",'optionLabelPath': "STRING",'valueBinding': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'contentBinding': depth0,'optionValuePath': depth0,'optionLabelPath': depth0,'valueBinding': depth0,'id': depth0,'class': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                                </div>\n                            </div>\n\n                            <div class=\"col-lg-3\">\n                                <div class=\"form-group\">\n                                    <label for=\"inputSteepness\">Steepness, max</label>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Steepness\"\n                                            data-content=\"Degrees on the steepest part of the route. Only digits are allowed.\"></button>\n                                    <div class=\"input-group\">\n                                        ");
  data.buffer.push(escapeExpression((helper = helpers.input || (depth0 && depth0.input),options={hash:{
    'pattern': ("App.Validate.numberRegex"),
    'value': ("degreesMax"),
    'id': ("inputSteepness"),
    'class': ("form-control")
  },hashTypes:{'pattern': "ID",'value': "ID",'id': "STRING",'class': "STRING"},hashContexts:{'pattern': depth0,'value': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "input", options))));
  data.buffer.push("\n                                        <div class=\"input-group-addon\">&#176;</div>\n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n\n                        <div class=\"row\">\n                            <div class=\"col-sm-6\">\n                                <div class=\"form-group\">\n                                    <div class=\"checkbox\">\n                                        <label>\n                                            ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "Ember.Checkbox", {hash:{
    'checkedBinding': ("haveHazards")
  },hashTypes:{'checkedBinding': "STRING"},hashContexts:{'checkedBinding': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("Hazards\n                                        </label>\n                                    </div>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Hazards\"\n                                            data-content=\"Description of any special hazards that skiers should be aware of. Description can have a maximum of 500 characters.\"></button>\n                                    ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'value': ("hazardsDescription"),
    'disabledBinding': ("haveNoHazards"),
    'maxlength': ("500"),
    'id': ("inputHazards"),
    'class': ("form-control")
  },hashTypes:{'value': "ID",'disabledBinding': "STRING",'maxlength': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'value': depth0,'disabledBinding': depth0,'maxlength': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n                                </div>\n                            </div>\n                            <div class=\"col-sm-6\">\n                                <div class=\"form-group\">\n                                    <div class=\"checkbox\">\n                                        <label>\n                                            ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "Ember.Checkbox", {hash:{
    'checkedBinding': ("requiresTools")
  },hashTypes:{'checkedBinding': "STRING"},hashContexts:{'checkedBinding': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("Mountaineering skills/equipment\n                                        </label>\n                                    </div>\n                                    <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                            title=\"Skills/Equipment\"\n                                            data-content=\"Description of any mountaineering skills or equipment needed. Rappels, glacier safety equipment etc. Description can have a maximum of 500 characters.\"></button>\n                                    ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'value': ("toolsDescription"),
    'disabledBinding': ("doesNotRequireTools"),
    'maxlength': ("500"),
    'id': ("inputTools"),
    'class': ("form-control")
  },hashTypes:{'value': "ID",'disabledBinding': "STRING",'maxlength': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'value': depth0,'disabledBinding': depth0,'maxlength': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n                                </div>\n                            </div>\n                        </div>\n\n                        \n                    </form>\n\n                    <div class=\"row spacing-y-large\">\n                        <div class=\"col-sm-12 small\">\n                            <div class=\"form-group\">\n                                <span class=\"asterisk required\"></span> Required field (tour cannot be published if not set) <br />\n                                <span class=\"asterisk recommended\"></span> Recommended field (tour will be marked as incomplete if not set)\n                            </div>\n                        </div>\n                    </div>\n                </div>\n\n                <div id=\"itinerary-panel\" class=\"tab-pane\">\n                    <div class=\"row\">\n                        <div class=\"col-sm-12\">\n                            <div class=\"form-group\">\n                                <label for=\"inputDescription\">Description<span class=\"asterisk required\"></span></label>\n                                <button type=\"button\" class=\"info pull-right\" data-toggle=\"popover\" data-trigger=\"focus\"\n                                        title=\"Description\"\n                                        data-content=\"Description of the tour itinerary and anything else that could be useful. Description can have a maximum of 8000 characters.\"></button>\n                                ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'value': ("itinerary"),
    'maxlength': ("8000"),
    'id': ("inputDescription"),
    'class': ("form-control large")
  },hashTypes:{'value': "ID",'maxlength': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'value': depth0,'maxlength': depth0,'id': depth0,'class': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n                            </div>\n                        </div>\n                    </div>\n                </div>\n\n                <div id=\"map-panel\" class=\"tab-pane\">\n                    <div class=\"row\">\n                        ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourEditMapView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                    </div>\n                </div>\n\n                <div id=\"images-panel\" class=\"tab-pane\">\n                    <div class=\"row\">\n                        <div class=\"col-sm-12\">\n                            <div class=\"spacing\">\n                                ");
  stack1 = helpers['if'].call(depth0, "isNew", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(13, program13, data),fn:self.program(11, program11, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                            </div>\n                        </div>\n                    </div>\n                </div>\n\n                <div id=\"history-panel\" class=\"tab-pane\">\n                    <div class=\"row\">\n                        <div class=\"col-sm-12 spacing\">\n                            Tour status: <em>");
  stack1 = helpers._triageMustache.call(depth0, "displayStatus", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</em>\n                        </div>\n                    </div>\n                    <div class=\"row\">\n                        <div class=\"col-sm-12\">\n                            <div class=\"table-responsive\">\n                                <table class=\"table table-striped\">\n                                    <thead>\n                                        <tr>\n                                            <th>Time</th>\n                                            <th>Type</th>\n                                            <th>User</th>\n                                            <th>Comment</th>\n                                        </tr>\n                                    </thead>\n                                    <tbody>\n                                        ");
  stack1 = helpers.each.call(depth0, "action", "in", "actions", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(15, program15, data),contexts:[depth0,depth0,depth0],types:["ID","ID","ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                                    </tbody>\n                                </table>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"tourDetailsGradeGuideModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">\n        <div class=\"modal-dialog modal-lg login-view\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\" id=\"myModalLabel\">Grades</h4>\n                </div>\n                <div class=\"modal-body\">\n                    ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "about-grades", options) : helperMissing.call(depth0, "partial", "about-grades", options))));
  data.buffer.push("\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"areaPickerModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Select area</h4>\n                </div>\n                <div class=\"modal-body\">\n                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.AreaPickerView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"discardChangesTourModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <h4>Unsaved changes</h4>\n                </div>\n                <div class=\"modal-body\">\n                    The tour has unsaved changes, do you want to discard them?\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-danger pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "confirmDiscardChanges", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Discard changes</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"confirmDeleteTourModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg areapicker-view\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Delete tour</h4>\n                </div>\n                <div class=\"modal-body\">\n                    Are you sure you want to delete the tour?\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-danger pull-right\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "confirmDeleteTour", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Delete tour</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"publishTourStep1Modal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Publish tour (Step 1 of 2)</h4>\n                </div>\n                <div class=\"modal-body\">\n                    ");
  stack1 = helpers['if'].call(depth0, "view.haveValidationErrors", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(20, program20, data),fn:self.program(17, program17, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-primary pull-right\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("view.haveValidationErrors")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "continueToPublishStep2", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Continue</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"publishTourStep2Modal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Publish tour (Step 2 of 2)</h4>\n                </div>\n                <div class=\"modal-body\">\n                    <form role=\"form\">\n                        <div class=\"form-group\">\n                            <label for=\"inputPublishComment\">What did you change?</label>\n                            ");
  data.buffer.push(escapeExpression((helper = helpers.textarea || (depth0 && depth0.textarea),options={hash:{
    'id': ("inputChangeComment"),
    'class': ("form-control"),
    'value': ("publishComment"),
    'maxlength': ("500")
  },hashTypes:{'id': "STRING",'class': "STRING",'value': "ID",'maxlength': "STRING"},hashContexts:{'id': depth0,'class': depth0,'value': depth0,'maxlength': depth0},contexts:[],types:[],data:data},helper ? helper.call(depth0, options) : helperMissing.call(depth0, "textarea", options))));
  data.buffer.push("\n                        </div>\n                    </form>\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-primary pull-right\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("view.isPublishDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "confirmPublishTour", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-cloud-upload\"></span> Publish</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"editTourHelpModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\">\n\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Help</h4>\n                </div>\n                <div class=\"modal-body\">\n                    ");
  data.buffer.push(escapeExpression((helper = helpers.partial || (depth0 && depth0.partial),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["STRING"],data:data},helper ? helper.call(depth0, "about-collaboration", options) : helperMissing.call(depth0, "partial", "about-collaboration", options))));
  data.buffer.push("\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Close</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n</div>\n\n<nav class=\"edit-navbar\" role=\"toolbar\">\n    <div class=\"container-fluid\">\n\n        <div class=\"navbar-header\">\n            <div class=\"btn-toolbar\">\n                <div class=\"btn-group pull-left\">\n                    <button class=\"btn btn-default\" data-toggle=\"modal\" data-target=\"#editTourHelpModal\">\n                        <span class=\"glyphicon glyphicon-question-sign\"></span> Help\n                    </button>\n                </div>\n\n                <div class=\"btn-group pull-right\">\n                    <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "startCancelingEditTour", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                        <span class=\"glyphicon glyphicon-share\"></span> Exit edit\n                    </button>\n                </div>\n\n                <div class=\"btn-group pull-right\">\n                    <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("isStartPublishDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "startPublishTour", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                        <span class=\"glyphicon glyphicon-cloud-upload\"></span> Publish\n                    </button>\n                </div>\n\n                ");
  stack1 = helpers.unless.call(depth0, "isPublished", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(26, program26, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                <div class=\"saving-info-container pull-right\">\n                    ");
  stack1 = helpers['if'].call(depth0, "hasChanges", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(29, program29, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                </div>\n\n            </div>\n        </div>\n\n    </div>\n</nav>\n");
  return buffer;
  
});

Ember.TEMPLATES["touredit"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var escapeExpression=this.escapeExpression;


  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourEditView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  
});

Ember.TEMPLATES["touritem-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, helper, options, self=this, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;

function program1(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push(" ");
  stack1 = helpers._triageMustache.call(depth0, "tour.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" ");
  return buffer;
  }

  data.buffer.push("<div class=\"row tour-item-view\">\n    <div class=\"col-sm-12\">   \n	    <div class=\"item-panel\">\n            <h4> ");
  stack1 = (helper = helpers['link-to'] || (depth0 && depth0['link-to']),options={hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0,depth0],types:["STRING","ID"],data:data},helper ? helper.call(depth0, "tour", "tour", options) : helperMissing.call(depth0, "link-to", "tour", "tour", options));
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push(" <span class=\"small uppercase\">");
  stack1 = helpers._triageMustache.call(depth0, "tour.area.name", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</span></h4>\n			<div class=\"item-props\">    \n				");
  data.buffer.push(escapeExpression((helper = helpers.resolveGradeName || (depth0 && depth0.resolveGradeName),options={hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data},helper ? helper.call(depth0, "tour.grade", options) : helperMissing.call(depth0, "resolveGradeName", "tour.grade", options))));
  data.buffer.push(" | \n				");
  stack1 = helpers._triageMustache.call(depth0, "tour.timingMin", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("-");
  stack1 = helpers._triageMustache.call(depth0, "tour.timingMax", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("h | \n				");
  stack1 = helpers._triageMustache.call(depth0, "tour.elevationGain", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("m &uarr; ");
  stack1 = helpers._triageMustache.call(depth0, "tour.elevationLoss", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("m &darr;\n			</div>\n			<div>\n			    ");
  stack1 = helpers._triageMustache.call(depth0, "tour.shortDescription", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n			</div>\n        </div>\n    </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["tourmap-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  


  data.buffer.push("<div class=\"mapContainer\">\n    <div id=\"tourMapRootElement\"></div>\n</div>");
  
});

Ember.TEMPLATES["tourmapedit-view"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var buffer = '', stack1, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  
  data.buffer.push("\n                        <div class=\"alert alert-warning\" role=\"alert\">\n                            <button type=\"button\" class=\"close\" data-dismiss=\"alert\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                            GPX file seems to be invalid, couldn't complete import.\n                        </div>\n                    ");
  }

function program3(depth0,data) {
  
  
  data.buffer.push("\n                        <div class=\"alert alert-success\" role=\"alert\">\n                            Map data was successfully imported.\n                        </div>\n                    ");
  }

function program5(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                        ");
  stack1 = helpers['if'].call(depth0, "view.loadingGpxData", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(8, program8, data),fn:self.program(6, program6, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program6(depth0,data) {
  
  
  data.buffer.push("\n                            <div class=\"alert alert-info\" role=\"alert\">\n                                Loading map data from GPX file... This can take a few seconds and the page may lock during loading\n                            </div>\n                        ");
  }

function program8(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                            <div class=\"alert alert-info\" role=\"alert\">\n                                For performance reasons the tracks might be compressed (some points ignored). Only tracks will be imported. Waypoints and metadata in the GPX file are ignored.\n                            </div>\n                            ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.GpxFileUploadView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                        ");
  return buffer;
  }

function program10(depth0,data) {
  
  var buffer = '', stack1;
  data.buffer.push("\n                        ");
  stack1 = helpers['if'].call(depth0, "view.gpxDataWasLoaded", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(13, program13, data),fn:self.program(11, program11, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                    ");
  return buffer;
  }
function program11(depth0,data) {
  
  var buffer = '';
  data.buffer.push("\n                            <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "closeGpxImportModal", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Close</button>\n                        ");
  return buffer;
  }

function program13(depth0,data) {
  
  
  data.buffer.push("\n                            <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                        ");
  }

  data.buffer.push("<div class=\"container-fluid map-edit-view\">\n    <div class=\"row\">\n        <div class=\"col-sm-12\">\n            <div class=\"btn-toolbar\" role=\"toolbar\">\n                <div class=\"btn-group spacing-x-large\">\n                    <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-toggle=\"dropdown\">\n                        <span class=\"glyphicon glyphicon-plus\"></span> Add path\n                        <span class=\"caret\"></span>\n                    </button>\n                    <ul class=\"dropdown-menu\" role=\"menu\">\n                        <li><a href=\"#\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "drawUpDownTrack", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-sort\"></span> Up/Down</a></li>\n                        <li><a href=\"#\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "drawUpTrack", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-arrow-up\"></span> Up</a></li>\n                        <li><a href=\"#\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "drawDownTrack", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push("><span class=\"glyphicon glyphicon-arrow-down\"></span> Down</a></li>\n                    </ul>\n                    <button class=\"btn btn-default\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("view.hasSummitPointMarker")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "drawSummitPoint", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">\n                        <span class=\"glyphicon glyphicon-map-marker\"></span> Summit point\n                    </button>\n                </div>\n\n                <div class=\"btn-group spacing-x-large\">\n                    <button class=\"btn btn-default\" data-toggle=\"modal\" data-target=\"#editPathsModal\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("view.isDeletePathsDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(">\n                        <span class=\"glyphicon glyphicon-edit\"></span> Edit paths\n                    </button>\n                    <button class=\"btn btn-default\" data-toggle=\"modal\" data-target=\"#confirmDeleteRoutesModal\" ");
  data.buffer.push(escapeExpression(helpers['bind-attr'].call(depth0, {hash:{
    'disabled': ("view.isDeletePathsDisabled")
  },hashTypes:{'disabled': "STRING"},hashContexts:{'disabled': depth0},contexts:[],types:[],data:data})));
  data.buffer.push(">\n                        <span class=\"glyphicon glyphicon-trash\"></span>\n                    </button>\n                </div>\n\n                <div class=\"btn-group spacing-x-large\">\n                    <button class=\"btn btn-default\" data-toggle=\"modal\" data-target=\"#importGpxModal\">\n                        <span class=\"glyphicon glyphicon-import\"></span> GPX\n                    </button>\n                </div>\n\n            </div>\n        </div>\n    </div>\n\n    <div class=\"mapContainer\">\n        <div id=\"tourEditMapRootElement\"></div>\n    </div>\n\n    <div class=\"mouse-position-container\">\n        <div>");
  stack1 = helpers._triageMustache.call(depth0, "view.mousePositionLat", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</div>\n        <div>");
  stack1 = helpers._triageMustache.call(depth0, "view.mousePositionLng", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("</div>\n    </div>\n\n    <div class=\"modal fade\" id=\"confirmDeleteRoutesModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Delete paths</h4>\n                </div>\n                <div class=\"modal-body\">\n                    Are you sure you want to delete the selected paths from the tour?\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-danger pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "deleteRoutes", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Delete</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"editPathsModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-sm\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\"><span aria-hidden=\"true\">&times;</span><span class=\"sr-only\">Close</span></button>\n                    <h4 class=\"modal-title\">Edit paths</h4>\n                </div>\n                <div class=\"modal-body\">\n                    <label for=\"inputAspect\">Set type on selected path(s)</label>\n                    ");
  data.buffer.push(escapeExpression(helpers.view.call(depth0, "Ember.Select", {hash:{
    'contentBinding': ("App.Fixtures.PathTypes"),
    'optionValuePath': ("content.value"),
    'optionLabelPath': ("content.name"),
    'valueBinding': ("view.draftPathType"),
    'id': ("inputMapPathType"),
    'class': ("form-control")
  },hashTypes:{'contentBinding': "STRING",'optionValuePath': "STRING",'optionLabelPath': "STRING",'valueBinding': "STRING",'id': "STRING",'class': "STRING"},hashContexts:{'contentBinding': depth0,'optionValuePath': depth0,'optionLabelPath': depth0,'valueBinding': depth0,'id': depth0,'class': depth0},contexts:[depth0],types:["ID"],data:data})));
  data.buffer.push("\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-default pull-right\" data-dismiss=\"modal\">Cancel</button>\n                    <button class=\"btn btn-primary pull-right\" data-dismiss=\"modal\" ");
  data.buffer.push(escapeExpression(helpers.action.call(depth0, "updatePathsType", {hash:{
    'target': ("view")
  },hashTypes:{'target': "STRING"},hashContexts:{'target': depth0},contexts:[depth0],types:["STRING"],data:data})));
  data.buffer.push(">Update</button>\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"modal fade\" id=\"importGpxModal\" tabindex=\"-1\" role=\"dialog\" aria-hidden=\"true\" data-backdrop=\"static\">\n        <div class=\"modal-dialog modal-lg\">\n            <div class=\"modal-content\">\n                <div class=\"modal-header\">\n                    <h4 class=\"modal-title\">Import GPX file</h4>\n                </div>\n                <div class=\"modal-body\">\n                    ");
  stack1 = helpers['if'].call(depth0, "view.gpxDataIsInvalid", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(1, program1, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                    ");
  stack1 = helpers['if'].call(depth0, "view.gpxDataWasLoaded", {hash:{},hashTypes:{},hashContexts:{},inverse:self.program(5, program5, data),fn:self.program(3, program3, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n\n                </div>\n                <div class=\"modal-footer\">\n                    ");
  stack1 = helpers.unless.call(depth0, "view.loadingGpxData", {hash:{},hashTypes:{},hashContexts:{},inverse:self.noop,fn:self.program(10, program10, data),contexts:[depth0],types:["ID"],data:data});
  if(stack1 || stack1 === 0) { data.buffer.push(stack1); }
  data.buffer.push("\n                </div>\n            </div>\n        </div>\n    </div>\n</div>");
  return buffer;
  
});

Ember.TEMPLATES["tournew"] = Ember.Handlebars.template(function anonymous(Handlebars,depth0,helpers,partials,data) {
this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Ember.Handlebars.helpers); data = data || {};
  var escapeExpression=this.escapeExpression;


  data.buffer.push(escapeExpression(helpers.view.call(depth0, "App.TourEditView", {hash:{},hashTypes:{},hashContexts:{},contexts:[depth0],types:["ID"],data:data})));
  
});